
import React, { useState, useEffect } from 'react';
import { Layout } from './components/Layout';
import { Home } from './components/Home';
import { Auth } from './components/Auth';
import { ApplyForm } from './components/ApplyForm';
import { CardPreview } from './components/CardPreview';
import { AirTicketBooking } from './components/AirTicketBooking';
import { AdminDashboard } from './components/AdminDashboard';
import { UserProfile } from './components/UserProfile';
import { User, ApplicationData, CardType } from './types';
import { translations } from './translations';
import { db } from './db';

const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [lang, setLang] = useState<'en' | 'bn'>('bn');
  const [view, setView] = useState<'home' | 'login' | 'register' | 'apply' | 'my-applications' | 'view-card' | 'admin' | 'profile'>('home');
  const [selectedCardType, setSelectedCardType] = useState<CardType | null>(null);
  const [applications, setApplications] = useState<ApplicationData[]>([]);
  const [currentCardView, setCurrentCardView] = useState<ApplicationData | null>(null);

  const t = translations[lang];

  // Load applications from DB on mount
  useEffect(() => {
    const loadApps = async () => {
      const data = await db.getApplications();
      setApplications(data);
    };
    loadApps();
  }, []);

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    if (user.role === 'admin') {
      setView('admin');
    } else {
      setView('home');
    }
  };

  const handleRegister = (user: User) => {
    setCurrentUser(user);
    setView('home');
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setView('home');
  };

  const handleApply = (type: CardType) => {
    if (!currentUser) {
      setView('login');
      return;
    }
    setSelectedCardType(type);
    setView('apply');
  };

  const scrollToSection = (sectionId: string) => {
    const performScroll = () => {
      const element = document.getElementById(sectionId);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    };

    if (view !== 'home') {
      setView('home');
      setTimeout(performScroll, 100);
    } else {
      performScroll();
    }
  };

  const submitApplication = async (data: ApplicationData) => {
    await db.saveApplication(data);
    const updatedApps = await db.getApplications();
    setApplications(updatedApps);
    setView('home');
    setTimeout(() => scrollToSection('applications-section'), 300);
  };

  const updateApplicationStatus = async (id: string, status: 'Approved' | 'Pending') => {
    await db.updateApplication(id, { status });
    const updatedApps = await db.getApplications();
    setApplications(updatedApps);
  };

  const deleteApplication = async (id: string) => {
    await db.deleteApplication(id);
    const updatedApps = await db.getApplications();
    setApplications(updatedApps);
  };

  const renderView = () => {
    switch (view) {
      case 'home':
        return (
          <Home 
            currentUser={currentUser}
            lang={lang} 
            t={t} 
            onApply={handleApply} 
            applications={applications} 
            onSelectCard={(app) => { setCurrentCardView(app); setView('view-card'); }} 
            onRegisterClick={() => setView('register')}
            onLoginClick={() => setView('login')}
            onViewApplications={() => scrollToSection('applications-section')}
            onViewServices={() => scrollToSection('services-section')}
          />
        );
      case 'login':
        return <Auth lang={lang} t={t} mode="login" onLogin={handleLogin} onToggle={() => setView('register')} onBack={() => setView('home')} />;
      case 'register':
        return <Auth lang={lang} t={t} mode="register" onRegister={handleRegister} onToggle={() => setView('login')} onBack={() => setView('home')} />;
      case 'apply':
        if (selectedCardType === 'AirTicket') {
          return <AirTicketBooking lang={lang} t={t} user={currentUser!} onComplete={submitApplication} onBack={() => setView('home')} />;
        }
        return <ApplyForm lang={lang} t={t} type={selectedCardType!} onComplete={submitApplication} onBack={() => setView('home')} existingApplications={applications} />;
      case 'view-card':
        return currentCardView ? <CardPreview lang={lang} t={t} data={currentCardView} onBack={() => setView('home')} /> : null;
      case 'admin':
        return (
          <AdminDashboard 
            lang={lang} 
            t={t} 
            applications={applications} 
            onApprove={(id) => updateApplicationStatus(id, 'Approved')}
            onDelete={deleteApplication}
            onBack={() => setView('home')}
          />
        );
      case 'profile':
        return currentUser ? (
          <UserProfile 
            user={currentUser} 
            applications={applications} 
            onBack={() => setView('home')} 
            lang={lang} 
            t={t} 
          />
        ) : null;
      default:
        return <Home 
          currentUser={currentUser}
          lang={lang} 
          t={t} 
          onApply={handleApply} 
          applications={applications} 
          onSelectCard={(app) => { setCurrentCardView(app); setView('view-card'); }} 
          onRegisterClick={() => setView('register')}
          onLoginClick={() => setView('login')}
          onViewApplications={() => scrollToSection('applications-section')}
          onViewServices={() => scrollToSection('services-section')}
        />;
    }
  };

  return (
    <Layout 
      currentUser={currentUser} 
      onLogout={handleLogout} 
      onLoginClick={() => setView('login')} 
      onRegisterClick={() => setView('register')} 
      onHomeClick={() => setView('home')}
      onServicesClick={() => scrollToSection('services-section')}
      onGuidelinesClick={() => scrollToSection('guidelines-section')}
      onMyApplicationsClick={() => scrollToSection('applications-section')}
      onAdminClick={() => setView('admin')}
      onProfileClick={() => setView('profile')}
      lang={lang}
      setLang={setLang}
      t={t}
    >
      {renderView()}
    </Layout>
  );
};

export default App;

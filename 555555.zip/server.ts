
import express from 'express';
import cors from 'cors';
import bodyParser from 'body-parser';
import { createServer as createViteServer } from 'vite';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DB_FILE = path.join(__dirname, 'database.json');

// Initialize database file if it doesn't exist
if (!fs.existsSync(DB_FILE)) {
  fs.writeFileSync(DB_FILE, JSON.stringify({
    users: [],
    applications: [],
    logs: [],
    walletTransactions: []
  }, null, 2));
}

const readDB = () => {
  const data = fs.readFileSync(DB_FILE, 'utf-8');
  return JSON.parse(data);
};

const writeDB = (data: any) => {
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
};

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(cors());
  app.use(bodyParser.json({ limit: '50mb' }));

  // API Routes
  app.get('/api/users', (req, res) => {
    const db = readDB();
    res.json(db.users);
  });

  app.post('/api/users', (req, res) => {
    const db = readDB();
    const newUser = req.body;
    db.users.push(newUser);
    writeDB(db);
    res.status(201).json(newUser);
  });

  app.get('/api/applications', (req, res) => {
    const db = readDB();
    res.json(db.applications);
  });

  app.post('/api/applications', (req, res) => {
    const db = readDB();
    const newApp = req.body;
    db.applications.unshift(newApp);
    writeDB(db);
    res.status(201).json(newApp);
  });

  app.put('/api/applications/:id', (req, res) => {
    const db = readDB();
    const { id } = req.params;
    const updates = req.body;
    const index = db.applications.findIndex((a: any) => a.id === id);
    if (index !== -1) {
      db.applications[index] = { ...db.applications[index], ...updates };
      writeDB(db);
      res.json(db.applications[index]);
    } else {
      res.status(404).json({ error: 'Application not found' });
    }
  });

  app.delete('/api/applications/:id', (req, res) => {
    const db = readDB();
    const { id } = req.params;
    db.applications = db.applications.filter((a: any) => a.id !== id);
    writeDB(db);
    res.status(204).send();
  });

  app.get('/api/logs', (req, res) => {
    const db = readDB();
    res.json(db.logs);
  });

  app.post('/api/logs', (req, res) => {
    const db = readDB();
    const newLog = req.body;
    db.logs.unshift(newLog);
    if (db.logs.length > 50) db.logs = db.logs.slice(0, 50);
    writeDB(db);
    res.status(201).json(newLog);
  });

  app.get('/api/wallet', (req, res) => {
    const db = readDB();
    res.json(db.walletTransactions || []);
  });

  app.post('/api/wallet', (req, res) => {
    const db = readDB();
    const newTx = req.body;
    if (!db.walletTransactions) db.walletTransactions = [];
    db.walletTransactions.unshift(newTx);
    writeDB(db);
    res.status(201).json(newTx);
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static('dist'));
    app.get('*', (req, res) => {
      res.sendFile(path.join(__dirname, 'dist/index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();

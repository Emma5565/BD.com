
import { User, ApplicationData, LiveEvent } from './types';

const API_BASE = '/api';

export const db = {
  // Users
  getUsers: async (): Promise<(User & { password?: string })[]> => {
    try {
      const res = await fetch(`${API_BASE}/users`);
      return await res.json();
    } catch (e) {
      console.error('Failed to fetch users', e);
      return [];
    }
  },
  
  saveUser: async (user: User & { password?: string }) => {
    try {
      await fetch(`${API_BASE}/users`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(user)
      });
      
      // Add to logs
      await db.addLog({
        id: Math.random().toString(),
        type: 'Registration',
        message: `Citizen ${user.fullName} registered a new account.`,
        timestamp: new Date()
      });
    } catch (e) {
      console.error('Failed to save user', e);
    }
  },

  findUser: async (phone: string) => {
    const users = await db.getUsers();
    return users.find(u => u.phone === phone);
  },

  // Applications
  getApplications: async (): Promise<ApplicationData[]> => {
    try {
      const res = await fetch(`${API_BASE}/applications`);
      return await res.json();
    } catch (e) {
      console.error('Failed to fetch applications', e);
      return [];
    }
  },

  saveApplication: async (app: ApplicationData) => {
    try {
      await fetch(`${API_BASE}/applications`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(app)
      });

      // Add to logs
      await db.addLog({
        id: Math.random().toString(),
        type: 'Payment',
        message: `${app.fullName} paid ${app.price} TK for ${app.type} Card from ${app.zilla}.`,
        timestamp: new Date()
      });

      // Add to wallet transactions
      await db.addWalletTransaction({
        id: Math.random().toString(36).substr(2, 9).toUpperCase(),
        phone: app.phone,
        type: 'Payment',
        amount: app.price || 0,
        method: 'Wallet',
        status: 'Success',
        timestamp: new Date().toISOString()
      });
    } catch (e) {
      console.error('Failed to save application', e);
    }
  },

  updateApplication: async (id: string, updates: Partial<ApplicationData>) => {
    try {
      const res = await fetch(`${API_BASE}/applications/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates)
      });
      const updatedApp = await res.json();
      
      if (updates.status === 'Approved') {
        await db.addLog({
          id: Math.random().toString(),
          type: 'Delivery',
          message: `Official approval granted for ${updatedApp.fullName}'s Smart Card.`,
          timestamp: new Date()
        });
      }
    } catch (e) {
      console.error('Failed to update application', e);
    }
  },

  deleteApplication: async (id: string) => {
    try {
      await fetch(`${API_BASE}/applications/${id}`, {
        method: 'DELETE'
      });
    } catch (e) {
      console.error('Failed to delete application', e);
    }
  },

  // Logs / Live Feed
  getLogs: async (): Promise<LiveEvent[]> => {
    try {
      const res = await fetch(`${API_BASE}/logs`);
      return await res.json();
    } catch (e) {
      console.error('Failed to fetch logs', e);
      return [];
    }
  },

  addLog: async (event: LiveEvent) => {
    try {
      await fetch(`${API_BASE}/logs`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(event)
      });
    } catch (e) {
      console.error('Failed to add log', e);
    }
  },
  
  // Wallet
  getWalletTransactions: async (): Promise<any[]> => {
    try {
      const res = await fetch(`${API_BASE}/wallet`);
      return await res.json();
    } catch (e) {
      console.error('Failed to fetch wallet transactions', e);
      return [];
    }
  },

  addWalletTransaction: async (tx: any) => {
    try {
      await fetch(`${API_BASE}/wallet`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(tx)
      });
    } catch (e) {
      console.error('Failed to add wallet transaction', e);
    }
  }
};

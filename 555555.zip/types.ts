
export type CardType = 'Family' | 'Farmer' | 'Student' | 'Business' | 'BMET' | 'AirTicket';

export interface User {
  fullName: string;
  phone: string;
  role: 'citizen' | 'admin';
}

export interface ApplicationData {
  id: string;
  type: CardType;
  fullName: string;
  nid: string;
  phone: string;
  fatherName: string;
  motherName: string;
  dob: string;
  zilla: string;
  upzilla: string;
  union: string;
  village: string;
  postOffice: string;
  bloodGroup: string;
  boldGroupSelect: string;
  selfie: string | null;
  nidFront: string | null;
  nidBack: string | null;
  signature: string | null;
  status: 'Pending' | 'Approved';
  referenceNo: string;
  passportNo?: string;
  tinCertificate?: string | null;
  from?: string;
  to?: string;
  price?: number;
  transactionId?: string;
  screenshot?: string | null;
}

export interface LiveEvent {
  id: string;
  type: 'Registration' | 'Payment' | 'Delivery' | 'Fraud' | 'Review' | 'Approval';
  message: string;
  timestamp: Date;
}

export interface WalletTransaction {
  id: string;
  phone: string;
  type: 'Deposit' | 'Withdrawal' | 'Payment';
  amount: number;
  method: string;
  status: 'Pending' | 'Success' | 'Rejected';
  timestamp: string;
  transactionId?: string;
  screenshot?: string | null;
  targetPhone?: string;
}


import React, { useState, useRef, useEffect } from 'react';
import { MessageCircle, X, Send, User, ShieldCheck } from 'lucide-react';
import { GoogleGenAI } from '@google/genai';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'admin';
  timestamp: Date;
}

interface LiveChatProps {
  lang: 'en' | 'bn';
  t: any;
}

export const LiveChat: React.FC<LiveChatProps> = ({ lang, t }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const handleSendMessage = async () => {
    if (!inputValue.trim()) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      text: inputValue,
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMsg]);
    setInputValue('');
    setIsTyping(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const prompt = `You are a helpful and professional customer support agent for the Bangladesh Government's Smart Family Card Portal. 
      The current user language is ${lang === 'en' ? 'English' : 'Bengali'}. 
      Always respond in ${lang === 'en' ? 'English' : 'Bengali'}.
      Answer questions about Family Cards (1320 TK), Farmer Cards (1100 TK), Student Cards (913 TK), Business Cards (1912 TK), and BMET Cards (7200 TK).
      Tell users that their cards are "Under Review" after submission until an administrator approves them.
      If asked for an admin panel, explain that this chat is monitored by official administrators.
      Be concise, polite, and official.
      
      User said: ${inputValue}`;

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
      });

      const adminMsg: Message = {
        id: (Date.now() + 1).toString(),
        text: response.text || (lang === 'en' ? "I'm sorry, I couldn't process that." : "দুঃখিত, আমি এটি প্রসেস করতে পারিনি।"),
        sender: 'admin',
        timestamp: new Date()
      };

      setMessages(prev => [...prev, adminMsg]);
    } catch (error) {
      console.error("Chat error:", error);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-[100] font-sans">
      {isOpen ? (
        <div className="w-80 md:w-96 h-[500px] bg-white rounded-3xl shadow-2xl border border-slate-200 flex flex-col overflow-hidden animate-in slide-in-from-bottom-4 duration-300">
          {/* Header */}
          <div className="bg-gradient-to-r from-[#006a4e] to-[#004d39] p-4 text-white flex justify-between items-center shadow-lg">
            <div className="flex items-center gap-3">
              <div className="relative">
                <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
                  <ShieldCheck size={20} />
                </div>
                <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-400 border-2 border-[#006a4e] rounded-full"></div>
              </div>
              <div>
                <p className="text-xs font-black uppercase tracking-widest">{t.chat_support}</p>
                <p className="text-[10px] font-bold text-white/70 uppercase">Online Agent</p>
              </div>
            </div>
            <button onClick={() => setIsOpen(false)} className="hover:bg-white/10 p-2 rounded-full transition-colors">
              <X size={20} />
            </button>
          </div>

          {/* Messages Area */}
          <div ref={scrollRef} className="flex-grow p-4 overflow-y-auto bg-slate-50 space-y-4">
            <div className="text-center mb-6">
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest bg-slate-100 py-1 px-3 rounded-full inline-block">
                Secure Chat Session Enabled
              </p>
            </div>
            
            {messages.length === 0 && (
              <div className="text-center py-10 px-6 opacity-50">
                <MessageCircle size={40} className="mx-auto text-[#006a4e] mb-4" />
                <p className="text-sm font-bold text-slate-800">{t.chat_welcome}</p>
              </div>
            )}

            {messages.map(msg => (
              <div key={msg.id} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[80%] p-3 rounded-2xl text-sm font-medium shadow-sm ${
                  msg.sender === 'user' 
                  ? 'bg-[#006a4e] text-white rounded-tr-none' 
                  : 'bg-white text-slate-800 border border-slate-100 rounded-tl-none'
                }`}>
                  {msg.text}
                </div>
              </div>
            ))}

            {isTyping && (
              <div className="flex justify-start">
                <div className="bg-white text-slate-400 p-3 rounded-2xl rounded-tl-none border border-slate-100 flex items-center gap-2">
                  <div className="flex gap-1">
                    <div className="w-1 h-1 bg-slate-300 rounded-full animate-bounce"></div>
                    <div className="w-1 h-1 bg-slate-300 rounded-full animate-bounce delay-100"></div>
                    <div className="w-1 h-1 bg-slate-300 rounded-full animate-bounce delay-200"></div>
                  </div>
                  <span className="text-[10px] font-black uppercase tracking-widest">{t.chat_admin_typing}</span>
                </div>
              </div>
            )}
          </div>

          {/* Input Area */}
          <div className="p-4 bg-white border-t border-slate-100 flex gap-2 items-center">
            <input 
              type="text" 
              placeholder={t.chat_placeholder}
              className="flex-grow p-3 bg-slate-100 rounded-2xl outline-none focus:ring-2 focus:ring-[#006a4e] text-sm font-medium"
              value={inputValue}
              onChange={e => setInputValue(e.target.value)}
              onKeyPress={e => e.key === 'Enter' && handleSendMessage()}
            />
            <button 
              onClick={handleSendMessage}
              disabled={!inputValue.trim() || isTyping}
              className="p-3 bg-[#006a4e] text-white rounded-2xl shadow-lg hover:bg-[#004d39] transition-all disabled:opacity-50 disabled:scale-100 active:scale-95"
            >
              <Send size={20} />
            </button>
          </div>
        </div>
      ) : (
        <button 
          onClick={() => setIsOpen(true)}
          className="bg-gradient-to-r from-[#006a4e] to-[#004d39] text-white p-4 md:p-5 rounded-full shadow-[0_10px_30px_rgba(0,106,78,0.4)] hover:scale-110 active:scale-95 transition-all flex items-center gap-3 group"
        >
          <div className="relative">
            <MessageCircle size={24} className="group-hover:rotate-12 transition-transform" />
            <div className="absolute -top-1 -right-1 w-3 h-3 bg-[#f42a41] border-2 border-white rounded-full"></div>
          </div>
          <span className="hidden md:inline font-black uppercase text-xs tracking-widest pr-2">{t.chat_support}</span>
        </button>
      )}
    </div>
  );
};


import React, { useState, useEffect, useCallback } from 'react';
import { CardType, ApplicationData, LiveEvent, User } from '../types';
import { db } from '../db';
import { 
  Users, 
  Sprout, 
  GraduationCap, 
  Briefcase, 
  Globe, 
  Plane,
  ChevronRight,
  ChevronLeft,
  ShieldCheck,
  CreditCard,
  FileText,
  CheckCircle2,
  MapPin,
  TrendingUp,
  Package,
  AlertTriangle,
  Activity,
  Info,
  HelpCircle,
  Clock,
  BookOpen,
  LayoutDashboard,
  UserCheck,
  Timer
} from 'lucide-react';

interface HomeProps {
  currentUser: User | null;
  lang: 'en' | 'bn';
  t: any;
  onApply: (type: CardType) => void;
  applications: ApplicationData[];
  onSelectCard: (app: ApplicationData) => void;
  onRegisterClick: () => void;
  onLoginClick: () => void;
  onViewApplications: () => void;
  onViewServices: () => void;
}

export const Home: React.FC<HomeProps> = ({ 
  currentUser, 
  lang, 
  t, 
  onApply, 
  applications, 
  onSelectCard, 
  onRegisterClick, 
  onLoginClick,
  onViewApplications,
  onViewServices
}) => {
  const [liveOrders, setLiveOrders] = useState<LiveEvent[]>([]);
  const [currentSlide, setCurrentSlide] = useState(0);

  const natureSlides = [
    {
      url: 'https://images.unsplash.com/photo-1596895111956-bf1cf0599ce5?auto=format&fit=crop&q=80&w=1600',
      caption: lang === 'bn' ? 'সুন্দরবন - বিশ্বের বৃহত্তম ম্যানগ্রোভ বন' : 'Sundarbans - The Largest Mangrove Forest'
    },
    {
      url: 'https://images.unsplash.com/photo-1622210334224-a2c727f1011c?auto=format&fit=crop&q=80&w=1600',
      caption: lang === 'bn' ? 'সিলেটের নয়নাভিরাম চা বাগান' : 'The Picturesque Tea Gardens of Sylhet'
    },
    {
      url: 'https://images.unsplash.com/photo-1583212292454-1fe6229603b7?auto=format&fit=crop&q=80&w=1600',
      caption: lang === 'bn' ? 'কক্সবাজার - বিশ্বের দীর্ঘতম সমুদ্র সৈকত' : "Cox's Bazar - The World's Longest Beach"
    },
    {
      url: 'https://images.unsplash.com/photo-1621305417409-f19c016e0b74?auto=format&fit=crop&q=80&w=1600',
      caption: lang === 'bn' ? 'শাপলা - আমাদের জাতীয় ফুল' : 'Water Lily - The National Flower'
    }
  ];

  const nextSlide = useCallback(() => {
    setCurrentSlide((prev) => (prev + 1) % natureSlides.length);
  }, [natureSlides.length]);

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + natureSlides.length) % natureSlides.length);
  };

  useEffect(() => {
    const slideInterval = setInterval(nextSlide, 8000);
    return () => clearInterval(slideInterval);
  }, [nextSlide]);

  const [stats, setStats] = useState({
    totalRegistered: 1245892,
    feesPaid: 812044,
    cardsDelivered: 545120,
    todayDelivery: 12504
  });
  const [lastUpdated, setLastUpdated] = useState<string | null>(null);

  useEffect(() => {
    const interval = setInterval(() => {
      const roll = Math.random();
      let updatedKey: string | null = null;
      
      setStats(prev => {
        const next = { ...prev };
        if (roll > 0.85) {
          next.totalRegistered += 1;
          updatedKey = 'totalRegistered';
        } else if (roll > 0.75) {
          next.feesPaid += 1;
          updatedKey = 'feesPaid';
        } else if (roll > 0.65) {
          next.todayDelivery += 1;
          updatedKey = 'todayDelivery';
        } else if (roll > 0.95) {
          next.cardsDelivered += 1;
          updatedKey = 'cardsDelivered';
        }
        return next;
      });

      if (updatedKey) {
        setLastUpdated(updatedKey);
        setTimeout(() => setLastUpdated(null), 2000);
      }
    }, 8000); // Realistic update frequency
    return () => clearInterval(interval);
  }, []);

  const formatNumber = (num: number) => {
    return num.toLocaleString('en-IN');
  };

  const pendingCount = applications.filter(app => app.status === 'Pending').length;
  const approvedCount = applications.filter(app => app.status === 'Approved').length;

  useEffect(() => {
    const loadLogs = async () => {
      const logs = await db.getLogs();
      
      // If we have real logs from the server, use them
      // Otherwise generate realistic mock logs
      const districts = ['Dhaka', 'Chittagong', 'Sylhet', 'Rajshahi', 'Khulna', 'Barisal', 'Rangpur', 'Mymensingh'];
      const names = ['Karim', 'Rahim', 'Morshed', 'Selina', 'Akash', 'Nasrin', 'Sohan', 'Laboni'];
      
      const generateOrder = (): LiveEvent => {
        const types: LiveEvent['type'][] = ['Registration', 'Payment', 'Delivery', 'Fraud', 'Review', 'Approval'];
        const type = types[Math.floor(Math.random() * types.length)];
        const district = districts[Math.floor(Math.random() * districts.length)];
        const name = names[Math.floor(Math.random() * names.length)];
        
        let message = "";
        if (lang === 'bn') {
          if (type === 'Registration') message = `নতুন নাগরিক ${name} (${district}) থেকে সফলভাবে নিবন্ধিত হয়েছেন।`;
          if (type === 'Payment') message = `${name} (${district}) এর পেমেন্ট সফলভাবে জমা হয়েছে।`;
          if (type === 'Delivery') message = `${district}-এ স্মার্ট কার্ড সফলভাবে পৌঁছে দেওয়া হয়েছে।`;
          if (type === 'Fraud') message = `সতর্কতা: ${name} এর সন্দেহজনক আবেদন বাতিল করা হয়েছে।`;
          if (type === 'Review') message = `${name} এর আবেদনটি বর্তমানে প্রশাসনিক যাচাইয়ের (Review) অধীনে আছে।`;
          if (type === 'Approval') message = `অভিনন্দন! ${name} এর স্মার্ট কার্ড আবেদনটি অনুমোদিত হয়েছে।`;
        } else {
          if (type === 'Registration') message = `New citizen ${name} successfully registered from ${district}.`;
          if (type === 'Payment') message = `Deposit successful for ${name} in ${district}.`;
          if (type === 'Delivery') message = `Smart card successfully delivered to ${district}.`;
          if (type === 'Fraud') message = `Alert: Suspicious application by ${name} has been blocked.`;
          if (type === 'Review') message = `Application from ${name} is currently under administrative review.`;
          if (type === 'Approval') message = `Success! Smart card application for ${name} has been approved.`;
        }

        return {
          id: Math.random().toString(),
          type,
          message,
          timestamp: new Date()
        };
      };

      if (logs.length > 0) {
        // Merge real logs with some mock ones to keep it "live" if server is quiet
        setLiveOrders(prev => {
          const combined = [...logs, ...prev].filter((v, i, a) => a.findIndex(t => t.id === v.id) === i);
          return combined.slice(0, 2); // Only show 2 items
        });
      } else {
        setLiveOrders(prev => [generateOrder(), ...prev.slice(0, 1)]); // Keep only 2 items total
      }
    };

    // Initial load
    loadLogs();
    // Update every 10 seconds as requested
    const interval = setInterval(loadLogs, 10000);
    return () => clearInterval(interval);
  }, [lang]);

  const serviceCards = [
    { 
      title: t.family_card, 
      icon: <Users size={28} />, 
      type: 'Family' as CardType, 
      color: 'bg-emerald-500',
      shadow: 'shadow-emerald-200',
      price: 1320,
      desc: lang === 'bn' ? 'সামাজিক নিরাপত্তা বেষ্টনী এবং সরকারি ত্রাণের জন্য।' : 'Social safety net & relief eligibility.',
      img: 'https://images.unsplash.com/photo-1542037104857-ffbb0b9155fb?auto=format&fit=crop&q=80&w=600'
    },
    { 
      title: t.farmer_card, 
      icon: <Sprout size={28} />, 
      type: 'Farmer' as CardType, 
      color: 'bg-green-600',
      shadow: 'shadow-green-200',
      price: 1100,
      desc: lang === 'bn' ? 'কৃষি ভর্তুকি, বীজ এবং সার সহায়তার জন্য।' : 'Subsidies, seeds, and fertilizer benefits.',
      img: 'https://images.unsplash.com/photo-1523348837708-15d4a09cfac2?auto=format&fit=crop&q=80&w=600'
    },
    { 
      title: t.student_card, 
      icon: <GraduationCap size={28} />, 
      type: 'Student' as CardType, 
      color: 'bg-blue-600',
      shadow: 'shadow-blue-200',
      price: 913,
      desc: lang === 'bn' ? 'শিক্ষা উপবৃত্তি এবং বিশেষ সরকারি সুযোগের জন্য।' : 'Education bursaries & travel discounts.',
      img: 'https://images.unsplash.com/photo-1523050853051-be991f85a6ad?auto=format&fit=crop&q=80&w=600'
    },
    { 
      title: t.business_card, 
      icon: <Briefcase size={28} />, 
      type: 'Business' as CardType, 
      color: 'bg-slate-700',
      shadow: 'shadow-slate-200',
      price: 1912,
      desc: lang === 'bn' ? 'ট্রেড লাইসেন্স ট্র্যাকিং এবং ডিজিটাল ট্যাক্স সেবার জন্য।' : 'Trade tracking & digital tax benefits.',
      img: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80&w=600'
    },
    { 
      title: t.bmet_card, 
      icon: <Globe size={28} />, 
      type: 'BMET' as CardType, 
      color: 'bg-indigo-600',
      shadow: 'shadow-indigo-200',
      price: 7200,
      desc: lang === 'bn' ? 'বিদেশের কর্মীদের অফিসিয়াল সরকারি পরিচয়ের জন্য।' : 'Official Migrant worker identification.',
      img: 'https://images.unsplash.com/photo-1569336415962-a4bd4f7df607?auto=format&fit=crop&q=80&w=600'
    },
    { 
      title: t.air_tickets, 
      icon: <Plane size={28} />, 
      type: 'AirTicket' as CardType, 
      color: 'bg-sky-500',
      shadow: 'shadow-sky-200',
      price: null,
      desc: lang === 'bn' ? 'সরকারি বিমানে বিশেষ ৪০% ছাড়ে ভ্রমণের জন্য।' : 'Discounted official govt airline travel.',
      img: 'https://images.unsplash.com/photo-1436491865332-7a61a109c0f2?auto=format&fit=crop&q=80&w=600'
    },
  ];

  const guidelines = [
    {
      title: lang === 'bn' ? 'আবেদন পদ্ধতি' : 'How to Apply',
      icon: <FileText className="text-gov-green" />,
      steps: lang === 'bn' 
        ? ['প্রথমে নিবন্ধন সম্পন্ন করুন', 'কাঙ্ক্ষিত কার্ড নির্বাচন করুন', 'সঠিক তথ্য প্রদান করুন', 'ফি পরিশোধ করুন ও ট্রানজেকশন আইডি দিন']
        : ['Complete registration first', 'Select desired card type', 'Provide accurate info', 'Pay fee & provide TrxID']
    },
    {
      title: lang === 'bn' ? 'যাচাইকরণ সময়' : 'Verification Time',
      icon: <Clock className="text-gov-red" />,
      steps: lang === 'bn'
        ? ['আবেদন জমা দেওয়ার পর ৭-১৫ দিন অপেক্ষা করুন', 'তথ্য সঠিক থাকলে কার্ড অনুমোদিত হবে', 'এসএমএস এর মাধ্যমে জানানো হবে']
        : ['Wait 7-15 days after submission', 'Cards approved if info is correct', 'Notification via SMS']
    },
    {
      title: lang === 'bn' ? 'প্রয়োজনীয় নথিপত্র' : 'Required Documents',
      icon: <BookOpen className="text-blue-600" />,
      steps: lang === 'bn'
        ? ['আসল এনআইডি কার্ডের কপি', 'পাসপোর্ট সাইজ ছবি', 'ডিজিটাল স্বাক্ষর', 'সচল মোবাইল নম্বর']
        : ['Original NID copy', 'Passport size photo', 'Digital signature', 'Active mobile number']
    }
  ];

  return (
    <div className="flex flex-col">
      {/* Professional Hero Banner with Nature Slider */}
      <section className="relative h-[650px] md:h-[800px] overflow-hidden bg-slate-900">
        {/* Nature Slider Background */}
        {natureSlides.map((slide, index) => (
          <div 
            key={index}
            className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${index === currentSlide ? 'opacity-100' : 'opacity-0'}`}
          >
            <div 
              className="absolute inset-0 bg-cover bg-center bg-no-repeat transition-transform duration-[8000ms] scale-100 group-hover:scale-110"
              style={{ backgroundImage: `url(${slide.url})` }}
            />
            <div className="absolute inset-0 bg-black/40 bg-gradient-to-b from-black/60 via-transparent to-black/70"></div>
          </div>
        ))}
        
        {/* Banner Navigation Controls */}
        <button 
          onClick={prevSlide}
          className="absolute left-4 top-1/2 -translate-y-1/2 z-30 p-3 bg-white/10 hover:bg-white/20 rounded-full text-white backdrop-blur-md transition-all border border-white/20 hidden md:block"
        >
          <ChevronLeft size={24} />
        </button>
        <button 
          onClick={nextSlide}
          className="absolute right-4 top-1/2 -translate-y-1/2 z-30 p-3 bg-white/10 hover:bg-white/20 rounded-full text-white backdrop-blur-md transition-all border border-white/20 hidden md:block"
        >
          <ChevronRight size={24} />
        </button>

        {/* Hero Content Overlay */}
        <div className="relative h-full max-w-7xl mx-auto px-4 flex flex-col items-center justify-center text-center text-white z-20">
          <div className="mb-4 animate-in fade-in zoom-in duration-1000 flex flex-col items-center">
            <img 
              src="https://upload.wikimedia.org/wikipedia/commons/thumb/8/84/Government_Seal_of_Bangladesh.svg/512px-Government_Seal_of_Bangladesh.svg.png" 
              className="w-20 h-20 md:w-28 md:h-28 drop-shadow-2xl mb-4 p-2 bg-white rounded-full" 
              alt="Seal" 
            />
          </div>

          <div className="mb-8 relative max-w-2xl animate-in slide-in-from-bottom duration-1000">
             <div className="inline-block px-4 py-1.5 bg-gov-red text-white text-[10px] md:text-xs font-black uppercase tracking-[0.2em] rounded-full mb-4 shadow-xl border border-white/20">
               {natureSlides[currentSlide].caption}
             </div>
             
             {currentUser ? (
               <div className="animate-in fade-in slide-in-from-top-4 duration-700 w-full flex flex-col items-center">
                  <div className="bg-white/10 backdrop-blur-md border border-white/20 px-8 py-5 rounded-3xl mb-4 inline-flex items-center gap-3">
                     <UserCheck className="text-gov-green" size={28} />
                     <span className="text-xl md:text-3xl font-black uppercase tracking-widest">
                       {lang === 'bn' ? `স্বাগতম, ${currentUser.fullName}` : `Welcome Back, ${currentUser.fullName}`}
                     </span>
                  </div>
                  
                  {/* Quick Stats Summary for User Dashboard */}
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mb-10 w-full max-w-2xl px-4">
                     <div className="bg-white/5 backdrop-blur-sm border border-white/10 p-5 rounded-2xl">
                        <p className="text-[10px] font-black uppercase text-white/50">{lang === 'bn' ? 'মোট আবেদন' : 'Total Applied'}</p>
                        <p className="text-2xl font-black">{applications.length}</p>
                     </div>
                     <div className="bg-yellow-500/10 border border-yellow-500/20 p-5 rounded-2xl text-yellow-400">
                        <p className="text-[10px] font-black uppercase opacity-70">{lang === 'bn' ? 'যাচাইধীন' : 'Under Review'}</p>
                        <p className="text-2xl font-black">{pendingCount}</p>
                     </div>
                     <div className="hidden sm:block bg-emerald-500/10 border border-emerald-500/20 p-5 rounded-2xl text-emerald-400">
                        <p className="text-[10px] font-black uppercase opacity-70">{lang === 'bn' ? 'অনুমোদিত' : 'Approved'}</p>
                        <p className="text-2xl font-black">{approvedCount}</p>
                     </div>
                  </div>

                  <div className="flex flex-col sm:flex-row gap-6">
                    <button 
                     onClick={onViewApplications}
                     className="bg-gov-red text-white px-12 py-5 rounded-full font-black uppercase text-sm shadow-2xl hover:scale-110 transition-all border-2 border-white/20 flex items-center gap-2"
                    >
                      <LayoutDashboard size={20} /> {lang === 'bn' ? 'আবেদনসমূহ দেখুন' : 'View Applications'}
                    </button>
                    <button 
                     onClick={onViewServices}
                     className="bg-white text-slate-900 px-12 py-5 rounded-full font-black uppercase text-sm shadow-2xl hover:scale-110 transition-all flex items-center gap-2"
                    >
                      <ChevronRight size={20} /> {lang === 'bn' ? 'সেবা সমূহ' : 'Explore Services'}
                    </button>
                  </div>
               </div>
             ) : (
               <div className="animate-in fade-in slide-in-from-bottom duration-1000">
                 <h2 className="text-4xl md:text-8xl font-black mb-2 uppercase tracking-tight drop-shadow-2xl text-white">
                   {lang === 'bn' ? 'বাংলাদেশ সরকার' : 'BANGLADESH GOVERNMENT'}
                 </h2>
                 <h3 className="text-5xl md:text-9xl font-black text-gov-red mb-6 tracking-tighter drop-shadow-2xl drop-shadow-white/20">
                   2026
                 </h3>
                 <div className="max-w-3xl mx-auto px-4">
                   <p className="text-sm md:text-xl font-bold mb-10 opacity-95 leading-relaxed text-gray-100 uppercase tracking-[0.2em] bg-black/40 py-4 px-8 rounded-2xl backdrop-blur-md border border-white/10">
                     {t.welcome_sub}
                   </p>
                 </div>
                 
                 <div className="flex flex-col sm:flex-row gap-6 justify-center">
                   <button 
                     onClick={onRegisterClick}
                     className="bg-[#006a4e] text-white px-14 py-5 rounded-full font-black uppercase text-sm shadow-2xl hover:bg-[#005a42] transition-all transform hover:scale-110 active:scale-95 border-2 border-white/20 min-w-[240px]"
                   >
                     {t.register}
                   </button>
                   <button 
                     onClick={onLoginClick}
                     className="bg-white text-gray-900 px-14 py-5 rounded-full font-black uppercase text-sm shadow-2xl hover:bg-gray-100 transition-all transform hover:scale-110 active:scale-95 min-w-[240px]"
                   >
                     {t.login}
                   </button>
                 </div>
               </div>
             )}
          </div>
          
          {/* Slider Pagination Dots */}
          <div className="absolute bottom-10 left-1/2 -translate-x-1/2 z-30 flex gap-3">
            {natureSlides.map((_, i) => (
              <button 
                key={i}
                onClick={() => setCurrentSlide(i)}
                className={`h-2.5 rounded-full transition-all duration-500 ${currentSlide === i ? 'w-12 bg-gov-red' : 'w-2.5 bg-white/40 hover:bg-white/70'}`}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Live Activity Section */}
      <section className="bg-white border-b border-gray-200 py-12">
        <div className="max-w-7xl mx-auto px-4">
           <div className="flex flex-col lg:flex-row gap-12">
              <div className="lg:w-[380px] shrink-0">
                 <div className="bg-[#006a4e] rounded-3xl p-6 text-white shadow-2xl border border-white/10 relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-[#f42a41]/20 rounded-full -mr-16 -mt-16 blur-3xl"></div>
                    <h4 className="text-xs font-black uppercase tracking-[0.2em] mb-6 flex items-center gap-2 text-emerald-100 relative z-10">
                       <TrendingUp size={14} className="text-white" /> {lang === 'bn' ? 'বর্তমান পরিসংখ্যান' : 'Current Statistics'}
                    </h4>
                    <div className="grid grid-cols-2 gap-3 relative z-10">
                        <div className={`bg-white/10 p-4 rounded-2xl border transition-all duration-500 group relative overflow-hidden ${lastUpdated === 'totalRegistered' ? 'border-white/40 bg-white/20 scale-[1.02]' : 'border-white/10'}`}>
                           {lastUpdated === 'totalRegistered' && <div className="absolute inset-0 bg-white/5 animate-pulse"></div>}
                           <div className="flex justify-between items-start mb-1 relative z-10">
                             <p className="text-[8px] font-black text-emerald-100/70 uppercase tracking-widest">{lang === 'bn' ? 'মোট নিবন্ধিত' : 'Total Registered'}</p>
                             <Users size={10} className={`transition-colors ${lastUpdated === 'totalRegistered' ? 'text-white' : 'text-white/50'}`} />
                           </div>
                           <p className={`text-xl font-black tracking-tighter transition-all duration-500 relative z-10 ${lastUpdated === 'totalRegistered' ? 'text-white scale-110 origin-left' : 'text-white'}`}>
                             {formatNumber(stats.totalRegistered)}
                           </p>
                           <div className="mt-2 h-0.5 w-full bg-white/10 rounded-full overflow-hidden relative z-10">
                             <div className={`h-full bg-[#f42a41] transition-all duration-1000 ${lastUpdated === 'totalRegistered' ? 'w-[86%]' : 'w-[85%]'}`}></div>
                           </div>
                        </div>
                        <div className={`bg-white/10 p-4 rounded-2xl border transition-all duration-500 group relative overflow-hidden ${lastUpdated === 'feesPaid' ? 'border-white/40 bg-white/20 scale-[1.02]' : 'border-white/10'}`}>
                           {lastUpdated === 'feesPaid' && <div className="absolute inset-0 bg-white/5 animate-pulse"></div>}
                           <div className="flex justify-between items-start mb-1 relative z-10">
                             <p className="text-[8px] font-black text-emerald-100/70 uppercase tracking-widest">{lang === 'bn' ? 'পেমেন্ট সম্পন্ন' : 'Fees Paid'}</p>
                             <CreditCard size={10} className={`transition-colors ${lastUpdated === 'feesPaid' ? 'text-white' : 'text-white/50'}`} />
                           </div>
                           <p className={`text-xl font-black tracking-tighter transition-all duration-500 relative z-10 ${lastUpdated === 'feesPaid' ? 'text-white scale-110 origin-left' : 'text-white'}`}>
                             {formatNumber(stats.feesPaid)}
                           </p>
                           <div className="mt-2 h-0.5 w-full bg-white/10 rounded-full overflow-hidden relative z-10">
                             <div className={`h-full bg-white transition-all duration-1000 ${lastUpdated === 'feesPaid' ? 'w-[71%]' : 'w-[70%]'}`}></div>
                           </div>
                        </div>
                        <div className={`bg-white/10 p-4 rounded-2xl border transition-all duration-500 group relative overflow-hidden ${lastUpdated === 'cardsDelivered' ? 'border-white/40 bg-white/20 scale-[1.02]' : 'border-white/10'}`}>
                           {lastUpdated === 'cardsDelivered' && <div className="absolute inset-0 bg-white/5 animate-pulse"></div>}
                           <div className="flex justify-between items-start mb-1 relative z-10">
                             <p className="text-[8px] font-black text-emerald-100/70 uppercase tracking-widest">{lang === 'bn' ? 'কার্ড ডেলিভারি' : 'Cards Delivered'}</p>
                             <Package size={10} className={`transition-colors ${lastUpdated === 'cardsDelivered' ? 'text-white' : 'text-white/50'}`} />
                           </div>
                           <p className={`text-xl font-black tracking-tighter transition-all duration-500 relative z-10 ${lastUpdated === 'cardsDelivered' ? 'text-white scale-110 origin-left' : 'text-white'}`}>
                             {formatNumber(stats.cardsDelivered)}
                           </p>
                           <div className="mt-2 h-0.5 w-full bg-white/10 rounded-full overflow-hidden relative z-10">
                             <div className={`h-full bg-white transition-all duration-1000 ${lastUpdated === 'cardsDelivered' ? 'w-[61%]' : 'w-[60%]'}`}></div>
                           </div>
                        </div>
                        <div className={`bg-white/10 p-4 rounded-2xl border transition-all duration-500 group relative overflow-hidden ${lastUpdated === 'todayDelivery' ? 'border-white/40 bg-white/20 scale-[1.02]' : 'border-white/10'}`}>
                           {lastUpdated === 'todayDelivery' && <div className="absolute inset-0 bg-white/5 animate-pulse"></div>}
                           <div className="flex justify-between items-start mb-1 relative z-10">
                             <p className="text-[8px] font-black text-emerald-100/70 uppercase tracking-widest">{lang === 'bn' ? 'আজকের ডেলিভারি' : "Today's Delivery"}</p>
                             <Timer size={10} className={`transition-colors ${lastUpdated === 'todayDelivery' ? 'text-white' : 'text-white/50'}`} />
                           </div>
                           <p className={`text-xl font-black tracking-tighter transition-all duration-500 relative z-10 ${lastUpdated === 'todayDelivery' ? 'text-white scale-110 origin-left' : 'text-white'}`}>
                             {formatNumber(stats.todayDelivery)}
                           </p>
                           <div className="mt-2 h-0.5 w-full bg-white/10 rounded-full overflow-hidden relative z-10">
                             <div className={`h-full bg-[#f42a41] transition-all duration-1000 ${lastUpdated === 'todayDelivery' ? 'w-[41%]' : 'w-[40%]'}`}></div>
                           </div>
                        </div>
                    </div>
                 </div>
              </div>

              <div className="flex-1 min-w-0">
                 <div className="bg-white rounded-[2rem] border border-slate-200 shadow-xl overflow-hidden h-full">
                    <div className="h-1.5 bg-gradient-to-r from-[#006a4e] via-[#f42a41] to-[#006a4e]"></div>
                    
                    <div className="p-6 md:p-8">
                       <div className="flex items-center justify-between mb-6">
                          <h4 className="text-sm md:text-lg font-black text-slate-800 uppercase tracking-tight flex items-center gap-3">
                             <div className="p-2 bg-emerald-50 rounded-xl text-[#006a4e]">
                                <Activity size={18} />
                             </div>
                             {t.live_feed}
                          </h4>
                          <div className="flex items-center gap-2 text-[8px] font-black text-slate-400 uppercase tracking-widest bg-slate-50 px-3 py-1.5 rounded-full border border-slate-100">
                            <div className="w-2 h-2 rounded-full bg-[#006a4e] animate-pulse"></div>
                            Live
                          </div>
                       </div>
                       
                        <div className="space-y-3">
                           {liveOrders.length > 0 ? liveOrders.map((order, i) => (
                              <div 
                               key={order.id} 
                               className={`p-4 rounded-2xl border-l-8 transition-all animate-in slide-in-from-top-4 duration-700 flex items-center gap-4 group ${
                                 order.type === 'Fraud' ? 'bg-red-50/50 border-l-[#f42a41] border-y border-r border-red-100' : 
                                 order.type === 'Payment' ? 'bg-emerald-50/50 border-l-[#006a4e] border-y border-r border-emerald-100' :
                                 order.type === 'Delivery' ? 'bg-blue-50/50 border-l-blue-600 border-y border-r border-blue-100' : 
                                 order.type === 'Review' ? 'bg-amber-50/50 border-l-amber-500 border-y border-r border-amber-100' :
                                 order.type === 'Approval' ? 'bg-green-50/50 border-l-emerald-600 border-y border-r border-emerald-100' :
                                 'bg-slate-50/50 border-l-slate-400 border-y border-r border-slate-100'
                               }`}
                              >
                                 <div className={`p-2.5 rounded-xl shadow-sm ${
                                   order.type === 'Fraud' ? 'bg-[#f42a41] text-white' : 
                                   order.type === 'Payment' ? 'bg-[#006a4e] text-white' :
                                   order.type === 'Delivery' ? 'bg-blue-600 text-white' : 
                                   order.type === 'Review' ? 'bg-amber-500 text-white' :
                                   order.type === 'Approval' ? 'bg-emerald-600 text-white' :
                                   'bg-slate-700 text-white'
                                 }`}>
                                   {order.type === 'Fraud' ? <AlertTriangle size={16} /> : 
                                    order.type === 'Payment' ? <CreditCard size={16} /> :
                                    order.type === 'Delivery' ? <Package size={16} /> : 
                                    order.type === 'Review' ? <Timer size={16} /> :
                                    order.type === 'Approval' ? <CheckCircle2 size={16} /> :
                                    <Users size={16} />}
                                 </div>
                                 <div className="flex-1 min-w-0">
                                    <div className="flex justify-between items-center mb-1">
                                      <div className="flex items-center gap-2">
                                        <span className={`text-[8px] font-black uppercase tracking-widest ${
                                          order.type === 'Fraud' ? 'text-red-600' : 
                                          order.type === 'Payment' ? 'text-[#006a4e]' : 'text-slate-500'
                                        }`}>
                                          {order.type}
                                        </span>
                                        {i === 0 && (
                                          <span className="bg-gov-red text-white text-[7px] font-black px-1.5 py-0.5 rounded-full animate-pulse">NEW</span>
                                        )}
                                      </div>
                                      <span className="text-[8px] font-bold text-slate-400">
                                        {new Date(order.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                      </span>
                                    </div>
                                    <p className="text-xs font-bold text-slate-700 leading-tight truncate">{order.message}</p>
                                 </div>
                              </div>
                           )) : (
                             <div className="h-40 flex flex-col items-center justify-center text-slate-300 gap-4 border-2 border-dashed border-slate-100 rounded-2xl bg-slate-50/30">
                               <Activity size={32} className="animate-pulse text-slate-200" />
                               <p className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">Loading Feed...</p>
                             </div>
                           )}
                        </div>
                    </div>
                 </div>
              </div>
           </div>
        </div>
      </section>

      {/* Applications Dashboard */}
      {applications.length > 0 && (
        <section id="applications-section" className="bg-slate-50 py-24 border-t border-gray-200 scroll-mt-32">
          <div className="max-w-7xl mx-auto px-4">
            <div className="flex flex-col md:flex-row justify-between items-center mb-12 gap-4">
              <div className="flex flex-col gap-1">
                <div className="flex items-center gap-2 text-[#006a4e] text-[10px] font-black uppercase tracking-widest">
                  <LayoutDashboard size={12} /> Citizen Dashboard
                </div>
                <h3 className="text-3xl font-black text-slate-800 uppercase tracking-tighter">
                  {lang === 'bn' ? 'আমার আবেদনসমূহ' : 'My Active Applications'}
                </h3>
              </div>
              <div className="bg-white px-6 py-3 rounded-2xl border border-slate-200 shadow-sm flex gap-8 text-[10px] font-black uppercase text-slate-400">
                <span className="flex items-center gap-2.5"><div className="w-2.5 h-2.5 rounded-full bg-yellow-400 animate-pulse"></div> {lang === 'bn' ? 'যাচাইধীন' : 'Under Review'}</span>
                <span className="flex items-center gap-2.5"><div className="w-2.5 h-2.5 rounded-full bg-[#006a4e]"></div> {lang === 'bn' ? 'অনুমোদিত' : 'Approved'}</span>
              </div>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {applications.map(app => (
                <div 
                  key={app.id}
                  onClick={() => onSelectCard(app)}
                  className={`bg-white p-8 rounded-3xl shadow-sm border-2 transition-all cursor-pointer group hover:shadow-2xl hover:-translate-y-2 flex flex-col h-full ${
                    app.status === 'Approved' ? 'border-emerald-100 hover:border-emerald-500' : 'border-yellow-100 hover:border-yellow-400'
                  }`}
                >
                  <div className="flex justify-between items-start mb-4">
                    <div className={`p-3 rounded-2xl ${
                      app.status === 'Approved' ? 'bg-emerald-50 text-emerald-600' : 'bg-yellow-50 text-yellow-600'
                    }`}>
                      {app.type === 'Family' ? <Users size={20} /> : app.type === 'Farmer' ? <Sprout size={20} /> : <LayoutDashboard size={20} />}
                    </div>
                    {app.status === 'Pending' && (
                       <Timer size={16} className="text-yellow-400 animate-spin-slow" />
                    )}
                  </div>
                  
                  <p className="font-black text-slate-800 text-lg mb-1 truncate">{app.fullName}</p>
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-6">{app.type} Card Portal</p>
                  
                  <div className="mt-auto">
                    <span className={`text-[9px] font-black uppercase px-4 py-2 rounded-xl flex items-center justify-center gap-2 ${
                      app.status === 'Approved' ? 'bg-emerald-100 text-emerald-700' : 'bg-yellow-100 text-yellow-700'
                    }`}>
                      {app.status === 'Approved' ? (lang === 'bn' ? 'অনুমোদিত' : 'Approved') : (lang === 'bn' ? 'যাচাইধীন (REVIEWING)' : 'Pending Approval')}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Services Grid */}
      <section id="services-section" className="max-w-7xl mx-auto px-4 py-20 scroll-mt-32">
        <div className="flex flex-col items-center mb-16">
           <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-[#006a4e]/5 text-[#006a4e] rounded-full text-[10px] font-black uppercase tracking-widest mb-4 border border-[#006a4e]/10">
             <ShieldCheck size={12} /> Official Citizen Services
           </div>
           <h3 className="text-3xl md:text-5xl font-black text-slate-800 uppercase tracking-tighter mb-4 text-center">
             {t.services_title}
           </h3>
           <div className="flex gap-1.5">
             <div className="w-12 h-1.5 bg-[#006a4e] rounded-full"></div>
             <div className="w-4 h-1.5 bg-[#f42a41] rounded-full"></div>
           </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
          {serviceCards.map(card => (
            <div 
              key={card.type} 
              className={`group bg-white rounded-3xl overflow-hidden shadow-xl ${card.shadow} hover:shadow-2xl transition-all duration-500 border border-slate-100 flex flex-col h-full transform hover:-translate-y-2`}
            >
              <div className="h-60 relative overflow-hidden">
                <img 
                  src={card.img} 
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" 
                  alt={card.title} 
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>
                <div className="absolute bottom-6 left-6 flex flex-col gap-1">
                  <div className="flex items-center gap-4">
                    <div className={`${card.color} p-4 rounded-2xl text-white shadow-lg`}>
                      {card.icon}
                    </div>
                    <h4 className="text-2xl font-black text-white drop-shadow-md">{card.title}</h4>
                  </div>
                  {card.price && (
                    <div className="mt-2 bg-gov-red text-white px-3 py-1 rounded-full text-[10px] font-black w-fit animate-pulse">
                      {t.price_label}: {card.price} {t.taka}
                    </div>
                  )}
                </div>
              </div>
              <div className="p-8 flex flex-col flex-grow">
                <p className="text-sm text-slate-500 mb-8 font-medium leading-relaxed flex-grow">
                  {card.desc}
                </p>
                <button 
                  onClick={() => onApply(card.type)}
                  className={`w-full py-4 ${card.color} text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:opacity-90 transition-all flex items-center justify-center gap-2 active:scale-95 shadow-lg`}
                >
                  {t.apply_now} <ChevronRight size={18} />
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Guidelines Section */}
      <section id="guidelines-section" className="bg-slate-900 text-white py-24 scroll-mt-32">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex flex-col items-center mb-16">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-white/5 text-slate-400 rounded-full text-[10px] font-black uppercase tracking-widest mb-4 border border-white/10">
              <Info size={12} /> Official Procedures
            </div>
            <h3 className="text-3xl md:text-5xl font-black uppercase tracking-tighter mb-4 text-center">
              {t.guidelines}
            </h3>
            <div className="flex gap-1.5">
              <div className="w-12 h-1.5 bg-[#006a4e] rounded-full"></div>
              <div className="w-4 h-1.5 bg-[#f42a41] rounded-full"></div>
            </div>
            <p className="mt-6 text-slate-400 font-bold uppercase tracking-widest text-center max-w-2xl">
              {lang === 'bn' ? 'সঠিকভাবে সেবা গ্রহণের জন্য নিচের নির্দেশিকাগুলো অনুসরণ করুন' : 'Follow these official guidelines for a smooth application process'}
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            {guidelines.map((guide, idx) => (
              <div key={idx} className="bg-white/5 border border-white/10 p-10 rounded-[2.5rem] backdrop-blur-sm hover:bg-white/10 transition-all group">
                <div className="bg-white p-4 rounded-2xl w-fit mb-8 shadow-2xl group-hover:scale-110 transition-transform">
                  {guide.icon}
                </div>
                <h4 className="text-2xl font-black uppercase tracking-tight mb-6">{guide.title}</h4>
                <ul className="space-y-4">
                  {guide.steps.map((step, i) => (
                    <li key={i} className="flex items-start gap-4">
                      <div className="w-6 h-6 rounded-full bg-[#006a4e] flex items-center justify-center text-[10px] font-black shrink-0 mt-0.5 shadow-lg">
                        {i + 1}
                      </div>
                      <span className="text-sm font-bold text-slate-300 leading-relaxed uppercase">{step}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          <div className="mt-16 bg-white/5 border border-white/10 rounded-3xl p-8 flex flex-col md:flex-row items-center justify-between gap-8">
            <div className="flex items-center gap-6">
              <div className="bg-[#f42a41] p-4 rounded-full">
                <HelpCircle size={32} />
              </div>
              <div>
                <h5 className="text-xl font-black uppercase tracking-tight">Need Urgent Help?</h5>
                <p className="text-sm text-slate-400 font-bold uppercase tracking-widest">Please contact with live chat and know updates result, Thank you !!</p>
              </div>
            </div>
            <div className="text-4xl font-black text-[#f42a41] tracking-tighter animate-pulse">
              LIVE CHAT
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

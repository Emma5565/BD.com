
import React, { useState, useEffect } from 'react';
import { User } from '../types';
import { 
  User as UserIcon, 
  Menu, 
  X, 
  ExternalLink,
  ShieldCheck,
  Zap,
  Activity,
  LogOut,
  LayoutDashboard,
  Settings
} from 'lucide-react';
import { LiveChat } from './LiveChat';

interface LayoutProps {
  children: React.ReactNode;
  currentUser: User | null;
  onLogout: () => void;
  onLoginClick: () => void;
  onRegisterClick: () => void;
  onHomeClick: () => void;
  onServicesClick: () => void;
  onGuidelinesClick: () => void;
  onMyApplicationsClick?: () => void;
  onAdminClick?: () => void;
  onProfileClick?: () => void;
  lang: 'en' | 'bn';
  setLang: (lang: 'en' | 'bn') => void;
  t: any;
}

export const Layout: React.FC<LayoutProps> = ({ 
  children, 
  currentUser, 
  onLogout, 
  onLoginClick, 
  onRegisterClick, 
  onHomeClick,
  onServicesClick,
  onGuidelinesClick,
  onMyApplicationsClick,
  onAdminClick,
  onProfileClick,
  lang, 
  setLang, 
  t 
}) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [tickerMessages, setTickerMessages] = useState<string[]>([]);

  useEffect(() => {
    const districts = ['Dhaka', 'Chittagong', 'Sylhet', 'Rajshahi', 'Khulna', 'Barisal', 'Rangpur', 'Mymensingh', 'Comilla', 'Noakhali'];
    const names = ['Karim', 'Rahim', 'Morshed', 'Selina', 'Akash', 'Nasrin', 'Faruk', 'Tania', 'Sohan', 'Laboni'];
    
    const generateMessages = () => {
      return Array.from({ length: 15 }).map(() => {
        const typeIdx = Math.floor(Math.random() * 4);
        const district = districts[Math.floor(Math.random() * districts.length)];
        const name = names[Math.floor(Math.random() * names.length)];
        
        if (lang === 'bn') {
          if (typeIdx === 0) return `🚨 জালিয়াতি সতর্কতা: ${name} নামে ভুয়া নিবন্ধন ${district} থেকে ব্লক করা হয়েছে।`;
          if (typeIdx === 1) return `💳 পেমেন্ট সফল: ${district} থেকে আবেদন ফি জমা হয়েছে।`;
          if (typeIdx === 2) return `🚚 ডেলিভারি আপডেট: আজ ${district}-এ স্মার্ট কার্ড বিতরণ সম্পন্ন।`;
          return `👤 নতুন আবেদন: ${name} (${district}) পোর্টালে নিবন্ধন করেছেন।`;
        } else {
          if (typeIdx === 0) return `🚨 FRAUD ALERT: Fake registration blocked for name "${name}" in ${district}.`;
          if (typeIdx === 1) return `💳 PAYMENT SUCCESS: Application fee received from ${district}.`;
          if (typeIdx === 2) return `🚚 DELIVERY UPDATE: Smart Cards delivered in ${district} today.`;
          return `👤 NEW ORDER: ${name} from ${district} just submitted a new application.`;
        }
      });
    };

    setTickerMessages(generateMessages());
    const interval = setInterval(() => setTickerMessages(generateMessages()), 30000);
    return () => clearInterval(interval);
  }, [lang]);

  const logoUrl = "https://upload.wikimedia.org/wikipedia/commons/thumb/8/84/Government_Seal_of_Bangladesh.svg/512px-Government_Seal_of_Bangladesh.svg.png";

  return (
    <div className="min-h-screen flex flex-col bg-[#f0f4f8]">
      {/* Official Top Bar */}
      <div className="h-2 bg-[#006a4e] w-full sticky top-0 z-[70]"></div>

      {/* Utility Bar */}
      <div className="bg-white border-b border-gray-100 py-2.5 px-4 text-[11px] md:text-xs text-gray-500 font-bold uppercase tracking-widest relative z-[60]">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex gap-4 items-center">
            <span className="hidden md:inline font-black text-slate-800">{t.gov_name}</span>
            <span className="md:hidden font-black">Govt. of Bangladesh</span>
            <div className="h-3 w-px bg-gray-200 mx-2"></div>
            <span className="text-[#006a4e] flex items-center gap-1 font-black"><Activity size={12} /> Live Orders</span>
          </div>
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setLang(lang === 'en' ? 'bn' : 'en')}
              className="px-3 py-1 bg-[#006a4e]/5 text-[#006a4e] border border-[#006a4e]/20 rounded-lg hover:bg-[#006a4e] hover:text-white transition-all font-black"
            >
              {lang === 'en' ? 'বাংল' : 'EN'}
            </button>
            <span className="text-gray-200">|</span>
            <a href="#" className="hover:text-[#006a4e] flex items-center gap-1">Accessibility <ExternalLink size={12} /></a>
          </div>
        </div>
      </div>

      {/* Main Header */}
      <header className="bg-white border-b-2 border-[#006a4e]/10 sticky top-2 z-50 transition-all shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          
          <div className="flex items-center gap-5 cursor-pointer group" onClick={onHomeClick}>
            <div className="bg-white p-1 rounded-full shadow-md border border-[#006a4e]/10 transform group-hover:scale-105 transition-transform duration-300">
              <img 
                src={logoUrl} 
                alt="Official Logo" 
                className="w-12 h-12 md:w-16 md:h-16 object-contain"
              />
            </div>
            <div className="hidden sm:block border-l-2 border-[#006a4e]/20 pl-5">
              <h1 className="text-lg md:text-2xl font-black leading-none tracking-tighter uppercase text-[#006a4e] mb-1">{t.portal_name}</h1>
              <p className="text-[9px] md:text-[10px] font-black text-[#f42a41] uppercase tracking-[0.3em] opacity-90">{t.ict_division}</p>
            </div>
          </div>

          <div className="flex items-center gap-4 md:gap-8">
            <nav className="hidden xl:flex items-center gap-8">
              <button onClick={onHomeClick} className="text-[11px] font-black uppercase tracking-widest text-slate-600 hover:text-[#006a4e] transition-colors">{t.home}</button>
              <button onClick={onServicesClick} className="text-[11px] font-black uppercase tracking-widest text-slate-600 hover:text-[#006a4e] transition-colors">{t.about}</button>
              <button onClick={onGuidelinesClick} className="text-[11px] font-black uppercase tracking-widest text-slate-600 hover:text-[#006a4e] transition-colors">{t.guidelines}</button>
              {currentUser && currentUser.role === 'citizen' && (
                <button 
                  onClick={onMyApplicationsClick} 
                  className="text-[11px] font-black uppercase tracking-widest text-[#006a4e] hover:opacity-70 transition-colors flex items-center gap-2"
                >
                  <LayoutDashboard size={14} /> {lang === 'bn' ? 'আমার আবেদনসমূহ' : 'My Applications'}
                </button>
              )}
            </nav>
            
            <div className="hidden xl:block h-8 w-px bg-slate-200"></div>

            {currentUser ? (
              <div className="flex items-center gap-4">
                 <button 
                  onClick={onProfileClick}
                  className="group bg-slate-50 hover:bg-slate-100 px-5 py-2.5 rounded-xl border border-slate-200 flex items-center gap-3 transition-all active:scale-95 shadow-sm"
                 >
                   <div className="p-2 bg-white rounded-lg border border-slate-100 text-gov-green group-hover:scale-110 transition-transform">
                    <UserIcon size={16} />
                   </div>
                   <div className="text-left leading-none">
                      <span className="block text-[8px] font-black uppercase tracking-tighter text-slate-400 mb-1">Authenticated Citizen</span>
                      <span className="block text-[11px] font-black uppercase tracking-wider text-slate-800">
                        {currentUser.fullName.split(' ')[0]}
                      </span>
                   </div>
                 </button>

                 <button 
                  onClick={onLogout} 
                  className="bg-[#f42a41] text-white px-6 py-3 rounded-xl font-black text-[10px] uppercase tracking-widest shadow-lg hover:bg-red-700 hover:scale-105 transition-all flex items-center gap-2 border border-white/10 active:scale-95"
                 >
                   <LogOut size={14} className="rotate-180" /> {t.logout}
                 </button>
              </div>
            ) : (
              <div className="flex gap-3">
                <button onClick={onLoginClick} className="px-5 py-2.5 border border-slate-200 rounded-xl text-[10px] font-black uppercase tracking-widest text-slate-600 hover:bg-slate-50 transition-all">{t.login}</button>
                <button onClick={onRegisterClick} className="bg-gov-green text-white px-5 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg hover:bg-emerald-700 transition-all active:scale-95">{t.register}</button>
              </div>
            )}
            
            <button className="xl:hidden p-2 text-slate-600 bg-slate-100 rounded-lg" onClick={() => setIsMenuOpen(!isMenuOpen)}>
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {isMenuOpen && (
          <div className="xl:hidden bg-white text-slate-900 border-t border-slate-100 p-4 absolute top-full left-0 right-0 shadow-2xl flex flex-col gap-4 animate-in slide-in-from-top duration-300">
            <button onClick={() => { onHomeClick(); setIsMenuOpen(false); }} className="p-4 text-xs font-black uppercase tracking-widest text-left border-b border-slate-50">{t.home}</button>
            <button onClick={() => { onServicesClick(); setIsMenuOpen(false); }} className="p-4 text-xs font-black uppercase tracking-widest text-left border-b border-slate-50">{t.about}</button>
            <button onClick={() => { onGuidelinesClick(); setIsMenuOpen(false); }} className="p-4 text-xs font-black uppercase tracking-widest text-left border-b border-slate-50">{t.guidelines}</button>
            {currentUser && currentUser.role === 'citizen' && (
               <button onClick={() => { onProfileClick?.(); setIsMenuOpen(false); }} className="p-4 text-xs font-black uppercase tracking-widest text-left border-b border-slate-50 text-gov-green">আমার প্রোফাইল (Profile)</button>
            )}
            {currentUser && currentUser.role === 'citizen' && (
               <button onClick={() => { onMyApplicationsClick?.(); setIsMenuOpen(false); }} className="p-4 text-xs font-black uppercase tracking-widest text-left border-b border-slate-50 text-gov-green">আমার আবেদনসমূহ</button>
            )}
            {currentUser && currentUser.role === 'admin' && (
               <button onClick={() => { onAdminClick?.(); setIsMenuOpen(false); }} className="p-4 text-xs font-black uppercase tracking-widest text-left border-b border-slate-50 text-emerald-600">অ্যাডমিন প্যানেল</button>
            )}
            {currentUser ? (
              <button onClick={() => { onLogout(); setIsMenuOpen(false); }} className="w-full bg-red-500 text-white p-4 rounded-xl font-black uppercase text-xs">{t.logout}</button>
            ) : (
              <div className="grid grid-cols-2 gap-2">
                <button onClick={() => { onLoginClick(); setIsMenuOpen(false); }} className="p-4 border border-slate-200 rounded-xl font-black uppercase text-xs">{t.login}</button>
                <button onClick={() => { onRegisterClick(); setIsMenuOpen(false); }} className="p-4 bg-[#006a4e] text-white rounded-xl font-black uppercase text-xs">{t.register}</button>
              </div>
            )}
          </div>
        )}
      </header>

      {/* Global Live Ticker */}
      <div className="bg-slate-900 text-white py-2.5 overflow-hidden whitespace-nowrap border-b border-white/5 relative z-40 shadow-inner">
        <div className="flex items-center">
          <div className="bg-[#f42a41] text-white px-3 py-1 rounded-r-full mr-4 text-[9px] font-black uppercase z-10 shrink-0 flex items-center gap-1.5 shadow-lg border-r border-white/20">
            <Zap size={10} className="fill-white" /> LIVE LOG
          </div>
          <div className="flex animate-marquee font-black text-[10px] md:text-sm tracking-wide text-slate-200">
            {tickerMessages.map((msg, i) => (
              <span key={i} className="mx-14 flex items-center gap-3">
                <span className="w-1.5 h-1.5 rounded-full bg-[#f42a41] animate-pulse"></span>
                {msg}
              </span>
            ))}
            {tickerMessages.map((msg, i) => (
              <span key={`dup-${i}`} className="mx-14 flex items-center gap-3">
                <span className="w-1.5 h-1.5 rounded-full bg-[#f42a41] animate-pulse"></span>
                {msg}
              </span>
            ))}
          </div>
        </div>
      </div>

      <main className="flex-grow">
        {children}
      </main>

      <footer className="bg-slate-900 text-slate-400 py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <div className="flex items-center justify-center gap-3 mb-8">
            <img src={logoUrl} className="w-14 h-14 object-contain brightness-200 grayscale" alt="Seal" />
            <span className="text-white font-black text-2xl uppercase tracking-tighter">Smart Portal 2026</span>
          </div>
          <p className="text-xs uppercase font-black tracking-widest mb-4">Official Service of ICT Division, Government of Bangladesh</p>
          <div className="text-[10px] text-slate-600 font-black uppercase tracking-[0.3em]">
             © 2026 Digital Bangladesh Project | GSOC Verified
          </div>
        </div>
      </footer>

      <LiveChat lang={lang} t={t} />
    </div>
  );
};

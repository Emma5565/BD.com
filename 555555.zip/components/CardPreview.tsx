
import React from 'react';
import { ApplicationData } from '../types';
import { ArrowLeft, CheckCircle2, ShieldCheck, Printer, Download, User as UserIcon, Globe, MapPin, Sprout, GraduationCap, Briefcase } from 'lucide-react';

interface CardPreviewProps {
  data: ApplicationData;
  onBack: () => void;
  lang: 'en' | 'bn';
  t: any;
}

export const CardPreview: React.FC<CardPreviewProps> = ({ data, onBack, lang, t }) => {
  const logoUrl = "https://upload.wikimedia.org/wikipedia/commons/thumb/1/14/Flag_of_the_Bangladesh_Nationalist_Party.svg/1024px-Flag_of_the_Bangladesh_Nationalist_Party.svg.png";
  
  const cardThemes = {
    Family: { 
      primary: 'bg-[#006a4e]', 
      header: 'bg-gradient-to-r from-[#f42a41] to-[#006a4e]',
      icon: <UserIcon />,
      border: 'border-[#006a4e]'
    },
    Farmer: { 
      primary: 'bg-[#1b5e20]', 
      header: 'bg-gradient-to-r from-[#388e3c] to-[#1b5e20]',
      icon: <Sprout />,
      border: 'border-[#1b5e20]'
    },
    Student: { 
      primary: 'bg-[#1a237e]', 
      header: 'bg-gradient-to-r from-[#3f51b5] to-[#1a237e]',
      icon: <GraduationCap />,
      border: 'border-[#1a237e]'
    },
    Business: { 
      primary: 'bg-[#263238]', 
      header: 'bg-gradient-to-r from-[#455a64] to-[#263238]',
      icon: <Briefcase />,
      border: 'border-[#263238]'
    },
    BMET: { 
      primary: 'bg-[#004d40]', 
      header: 'bg-gradient-to-r from-[#00695c] to-[#004d40]',
      icon: <Globe />,
      border: 'border-[#ffeb3b]'
    },
    AirTicket: { 
      primary: 'bg-sky-600', 
      header: 'bg-sky-700',
      icon: <Globe />,
      border: 'border-sky-600'
    }
  };

  const theme = cardThemes[data.type as keyof typeof cardThemes] || cardThemes.Family;

  return (
    <div className="max-w-4xl mx-auto px-4 py-12 md:py-20">
      <div className="flex flex-col md:flex-row justify-between items-center gap-6 mb-12">
        <button onClick={onBack} className="flex items-center gap-2 text-gov-green font-black uppercase text-xs">
          <ArrowLeft size={16} /> {t.back_dashboard}
        </button>
        <div className="flex gap-4">
          <button className="bg-slate-100 text-slate-700 px-6 py-3 rounded-xl font-bold text-xs uppercase hover:bg-slate-200 transition-all flex items-center gap-2">
            <Download size={16} /> পিডিএফ সংরক্ষণ (PDF)
          </button>
          <button className="bg-gov-green text-white px-6 py-3 rounded-xl font-bold text-xs uppercase hover:bg-opacity-90 shadow-lg transition-all flex items-center gap-2">
            <Printer size={16} /> কার্ড প্রিন্ট করুন
          </button>
        </div>
      </div>

      <div className="bg-green-50 border border-green-200 p-8 rounded-2xl flex items-center gap-6 mb-16 shadow-sm">
        <div className="bg-white p-3 rounded-full shadow-md">
          <CheckCircle2 className="w-8 h-8 text-gov-green" />
        </div>
        <div>
          <h3 className="text-xl md:text-2xl font-black text-gov-green uppercase tracking-tight">আবেদনটি সফলভাবে জমা দেওয়া হয়েছে!</h3>
          <p className="text-xs md:text-sm text-slate-500 mt-1 font-bold uppercase">{t.ref_no}: <span className="text-gov-red font-mono">{data.referenceNo}</span></p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        <div className="space-y-4">
          <p className="text-center font-black text-slate-400 uppercase tracking-[0.3em] text-[10px]">ই-কার্ডের সামনের অংশ (Front)</p>
          <div className={`aspect-[1.6/1] bg-white rounded-2xl shadow-2xl border-[5px] ${theme.border} overflow-hidden relative group transition-transform hover:scale-[1.02]`}>
            <div className={`p-3 md:p-4 flex justify-between items-center text-white ${theme.header}`}>
              <img src={logoUrl} className="w-10 h-8 md:w-14 md:h-10 object-contain brightness-200" alt="Seal" />
              <div className="text-center">
                <h4 className="text-[7px] md:text-[9px] font-black uppercase tracking-widest opacity-80">{t.gov_name}</h4>
                <p className="text-xs md:text-base font-black tracking-widest mt-0.5">{data.type === 'Family' ? 'স্মার্ট ফ্যামিলি কার্ড' : data.type === 'Farmer' ? 'স্মার্ট কৃষক কার্ড' : data.type === 'Student' ? 'স্মার্ট স্টুডেন্ট কার্ড' : data.type === 'Business' ? 'স্মার্ট বিজনেস কার্ড' : 'স্মার্ট বিএমইটি কার্ড'}</p>
              </div>
              <ShieldCheck className="w-8 h-8 opacity-40" />
            </div>

            <div className="p-4 md:p-5 flex gap-4 md:gap-5 h-full bg-white relative">
              <div className="flex flex-col items-center">
                <div className={`w-24 h-30 md:w-28 md:h-34 bg-slate-100 border-2 ${theme.border} rounded-lg overflow-hidden shadow-inner`}>
                  <img src={data.selfie || 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=200'} alt="User" className="w-full h-full object-cover" />
                </div>
                <div className="mt-2 text-center w-full border-t border-slate-100 pt-1">
                   {data.signature ? (
                     <img src={data.signature} className="h-6 mx-auto object-contain grayscale" alt="Sign" />
                   ) : (
                     <p className="text-[10px] font-serif italic text-slate-500">স্বাক্ষর নেই</p>
                   )}
                   <p className="text-[5px] font-black text-slate-400 uppercase tracking-widest mt-0.5">যাচাইকৃত ডিজিটাল স্বাক্ষর</p>
                </div>
              </div>

              <div className="flex-1 space-y-1.5 mt-1 overflow-hidden">
                <div className="border-b border-slate-100 pb-1">
                  <p className="text-[6px] md:text-[7px] text-gov-red font-black uppercase tracking-widest">নাম (Name)</p>
                  <p className="text-[10px] md:text-sm font-black text-slate-800 uppercase leading-none truncate">{data.fullName}</p>
                </div>
                <div className="grid grid-cols-2 gap-1.5">
                  <div>
                    <p className="text-[6px] text-slate-400 font-black uppercase tracking-widest">পিতা (Father)</p>
                    <p className="text-[8px] md:text-[10px] font-bold text-slate-700 truncate">{data.fatherName}</p>
                  </div>
                  <div>
                    <p className="text-[6px] text-slate-400 font-black uppercase tracking-widest">মাতা (Mother)</p>
                    <p className="text-[8px] md:text-[10px] font-bold text-slate-700 truncate">{data.motherName}</p>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-1.5">
                  <div>
                    <p className="text-[6px] text-slate-400 font-black uppercase tracking-widest">জন্ম (D.O.B)</p>
                    <p className="text-[8px] md:text-[10px] font-black text-slate-800">{data.dob}</p>
                  </div>
                  <div>
                    <p className="text-[6px] text-gov-red font-black uppercase tracking-widest">এনআইডি (NID)</p>
                    <p className="text-[8px] md:text-[10px] font-black text-gov-red">{data.nid}</p>
                  </div>
                </div>
                <div className="flex justify-between items-center mt-2 bg-slate-50 p-1.5 rounded-lg border border-slate-100">
                   <div>
                     <p className="text-[5px] text-slate-400 font-black uppercase">রক্তের গ্রুপ</p>
                     <p className="text-[10px] font-black text-gov-red">{data.bloodGroup || 'N/A'}</p>
                   </div>
                   <div className="text-right">
                     <p className="text-[5px] text-slate-400 font-black uppercase">বিভাগ</p>
                     <p className="text-[8px] font-black text-slate-700 truncate max-w-[80px]">{data.boldGroupSelect || 'সাধারণ'}</p>
                   </div>
                </div>
              </div>

              <div className="flex flex-col items-center justify-center gap-1">
                <img src={`https://api.qrserver.com/v1/create-qr-code/?size=100x100&data=https://bangladesh.gov.bd/card/${data.id}`} className="w-14 h-14" alt="QR" />
                <p className="text-[5px] font-black text-slate-400 uppercase tracking-widest">ডিজিটাল আইডি</p>
              </div>
            </div>
            
            {data.status === 'Pending' && (
              <div className="absolute inset-0 bg-white/95 backdrop-blur-sm flex flex-col items-center justify-center p-8 text-center border-2 border-yellow-500 m-4 rounded-xl">
                <div className="bg-yellow-500 text-white px-4 py-1 rounded-full font-black text-[10px] uppercase tracking-widest mb-3 animate-pulse">{t.review_status}</div>
                <p className="text-xs font-black text-slate-800 uppercase leading-relaxed">{t.review_desc}</p>
              </div>
            )}
          </div>
        </div>

        <div className="space-y-4">
          <p className="text-center font-black text-slate-400 uppercase tracking-[0.3em] text-[10px]">ই-কার্ডের পিছনের অংশ (Back)</p>
          <div className="aspect-[1.6/1] bg-slate-50 rounded-2xl shadow-2xl border border-slate-200 overflow-hidden p-6 flex flex-col justify-between relative transition-transform hover:scale-[1.02]">
             <div className="flex justify-between items-start">
               <div className="space-y-4 flex-1">
                 <div className="bg-slate-900 text-white p-3 rounded-xl shadow-lg border border-white/10">
                    <p className="text-[7px] font-black text-slate-400 uppercase tracking-widest mb-1">আবাসস্থল সংক্রান্ত তথ্য (Address)</p>
                    <p className="text-[9px] md:text-[11px] text-slate-200 font-black leading-tight">
                      গ্রাম/রাস্তা: {data.village}<br />
                      ইউনিয়ন: {data.union}<br />
                      ডাকঘর: {data.postOffice}<br />
                      উপজেলা: {data.upzilla}<br />
                      জেলা: {data.zilla}
                    </p>
                 </div>
                 <div>
                   <p className="text-[7px] font-black text-slate-400 uppercase tracking-widest mb-1">{t.ref_no}</p>
                   <p className="text-xs md:text-sm font-mono font-black text-gov-green bg-white border border-slate-200 px-2 py-1 rounded-lg inline-block">{data.referenceNo}</p>
                 </div>
               </div>
               <div className="text-center bg-white p-3 rounded-2xl shadow-xl border border-slate-100 flex flex-col items-center gap-2">
                 <img src={`https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${data.referenceNo}`} className="w-20 h-20 md:w-24 md:h-24" alt="Ref QR" />
                 <p className="text-[6px] font-black text-slate-500 uppercase tracking-widest">অভ্যন্তরীণ যাচাইকরণ</p>
               </div>
             </div>

             <div className="border-t border-slate-200 pt-4 text-[7px] md:text-[8px] text-slate-400 italic font-bold uppercase tracking-tight leading-relaxed">
               সতর্কবার্তা: এটি একটি ডিজিটাল ইলেকট্রনিক সার্টিফিকেট। এই কার্ড জাল করা বা পরিবর্তন করা আইনত দণ্ডনীয় অপরাধ। কার্ডটি খুঁজে পেলে নিকটস্থ উপজেলা নির্বাচন অফিসে জমা দিন।
             </div>

             {data.status === 'Pending' && (
              <div className="absolute inset-0 bg-white/95 backdrop-blur-sm flex flex-col items-center justify-center p-8 text-center border-2 border-slate-200 m-4 rounded-xl">
                <ShieldCheck size={32} className="text-slate-200 mb-3" />
                <p className="text-[8px] font-black text-slate-400 uppercase">প্রশাসনিক অনুমোদন না হওয়া পর্যন্ত তথ্য গোপন রাখা হয়েছে।</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

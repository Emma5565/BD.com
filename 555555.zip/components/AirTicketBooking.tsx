
import React, { useState } from 'react';
import { User, ApplicationData } from '../types';
// Fixed: Added ShieldCheck to the lucide-react import list.
import { ArrowLeft, Plane, MapPin, Calendar, CreditCard, Copy, Upload, CheckCircle, Globe, Search, ShieldCheck } from 'lucide-react';

interface AirTicketBookingProps {
  user: User;
  onComplete: (data: ApplicationData) => void;
  onBack: () => void;
  lang: 'en' | 'bn';
  t: any;
}

export const AirTicketBooking: React.FC<AirTicketBookingProps> = ({ user, onComplete, onBack, lang, t }) => {
  const [step, setStep] = useState(1);
  const [category, setCategory] = useState<'Domestic' | 'International'>('Domestic');
  const [searchQuery, setSearchQuery] = useState('');
  
  const [ticketData, setTicketData] = useState({
    from: 'Bangladesh (Dhaka)',
    to: '',
    date: '',
    price: 0,
    discountPrice: 0,
    txId: '',
    screenshot: null as string | null,
    passportNo: ''
  });

  const domesticRoutes = [
    { from: 'Dhaka', to: 'Chittagong', price: 4500 },
    { from: 'Dhaka', to: 'Sylhet', price: 4200 },
    { from: 'Dhaka', to: 'Rajshahi', price: 4000 },
    { from: 'Dhaka', to: 'Saidpur', price: 4800 },
    { from: 'Dhaka', to: 'Cox\'s Bazar', price: 6500 },
    { from: 'Dhaka', to: 'Barisal', price: 4300 },
    { from: 'Dhaka', to: 'Jessore', price: 4100 },
  ];

  const internationalRoutes = [
    { from: 'Dhaka', to: 'Dubai (UAE)', price: 45000 },
    { from: 'Dhaka', to: 'London (UK)', price: 95000 },
    { from: 'Dhaka', to: 'New York (USA)', price: 145000 },
    { from: 'Dhaka', to: 'Singapore', price: 35000 },
    { from: 'Dhaka', to: 'Kuala Lumpur (Malaysia)', price: 32000 },
    { from: 'Dhaka', to: 'Riyadh (Saudi Arabia)', price: 55000 },
    { from: 'Dhaka', to: 'Jeddah (Saudi Arabia)', price: 58000 },
    { from: 'Dhaka', to: 'Kolkata (India)', price: 8500 },
    { from: 'Dhaka', to: 'Bangkok (Thailand)', price: 28000 },
    { from: 'Dhaka', to: 'Doha (Qatar)', price: 48000 },
    { from: 'Dhaka', to: 'Sydney (Australia)', price: 120000 },
    { from: 'Dhaka', to: 'Toronto (Canada)', price: 160000 },
    { from: 'Dhaka', to: 'Paris (France)', price: 88000 },
    { from: 'Dhaka', to: 'Tokyo (Japan)', price: 110000 },
  ];

  const currentRoutes = category === 'Domestic' ? domesticRoutes : internationalRoutes;
  const filteredRoutes = currentRoutes.filter(r => 
    r.to.toLowerCase().includes(searchQuery.toLowerCase()) || 
    r.from.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleRouteSelect = (route: typeof domesticRoutes[0]) => {
    setTicketData({
      ...ticketData,
      from: route.from,
      to: route.to,
      price: route.price,
      discountPrice: Math.floor(route.price * 0.6) // 40% Discount
    });
    setStep(2);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setTicketData(prev => ({ ...prev, screenshot: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const finalData: ApplicationData = {
      id: Math.random().toString(36).substr(2, 9),
      type: 'AirTicket',
      fullName: user.fullName,
      nid: 'VERIFIED',
      phone: user.phone,
      fatherName: 'N/A',
      motherName: 'N/A',
      dob: 'N/A',
      zilla: 'National',
      upzilla: 'Aviation',
      union: 'N/A',
      village: 'Airport Road',
      postOffice: '1229',
      bloodGroup: 'N/A',
      boldGroupSelect: category === 'International' ? 'International Passenger' : 'Domestic Passenger',
      selfie: null,
      nidFront: null,
      nidBack: null,
      signature: 'E-TICKET',
      status: 'Pending',
      referenceNo: 'TKT-' + Math.floor(Math.random() * 900000 + 100000),
      from: ticketData.from,
      to: ticketData.to,
      price: ticketData.discountPrice,
      transactionId: ticketData.txId,
      screenshot: ticketData.screenshot,
      passportNo: ticketData.passportNo,
    };
    onComplete(finalData);
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <button onClick={onBack} className="flex items-center gap-2 text-gov-green font-black mb-6 uppercase text-xs">
        <ArrowLeft className="w-4 h-4" /> {t.back}
      </button>

      <div className="bg-white rounded-[2rem] shadow-2xl overflow-hidden border-4 border-slate-900">
        <div className="bg-gradient-to-r from-sky-600 to-indigo-700 p-10 text-white relative">
          <div className="absolute top-0 right-0 p-10 opacity-10">
            <Globe size={160} />
          </div>
          <div className="relative z-10 flex flex-col md:flex-row justify-between items-center gap-6">
            <div>
              <h2 className="text-4xl font-black italic flex items-center gap-4">
                <Plane className="w-12 h-12" /> Smart Air Travel
              </h2>
              <p className="text-sm opacity-90 font-black mt-2 uppercase tracking-[0.3em]">
                {category === 'Domestic' ? 'Internal Flight Network' : 'Global International Network'}
              </p>
              <div className="mt-4 bg-white/20 px-4 py-2 rounded-full text-[10px] font-black w-fit uppercase animate-pulse border border-white/30">
                Special Government 40% Rebate Active
              </div>
            </div>
            <div className="bg-black/20 p-4 rounded-3xl text-center backdrop-blur-md border border-white/10 min-w-[140px]">
              <span className="text-[10px] font-black block opacity-70 uppercase tracking-widest mb-1">Application Step</span>
              <span className="text-3xl font-black">{step} <span className="text-sm opacity-50">/ 3</span></span>
            </div>
          </div>
        </div>

        <div className="p-8 md:p-12">
          {step === 1 && (
            <div className="animate-in fade-in duration-500">
              <div className="flex flex-col md:flex-row gap-6 mb-10">
                <div className="flex bg-slate-100 p-2 rounded-2xl flex-1">
                  <button 
                    onClick={() => setCategory('Domestic')}
                    className={`flex-1 py-4 rounded-xl font-black text-xs uppercase tracking-widest transition-all ${category === 'Domestic' ? 'bg-white shadow-lg text-sky-600' : 'text-slate-500 hover:text-slate-800'}`}
                  >
                    Domestic Routes
                  </button>
                  <button 
                    onClick={() => setCategory('International')}
                    className={`flex-1 py-4 rounded-xl font-black text-xs uppercase tracking-widest transition-all ${category === 'International' ? 'bg-white shadow-lg text-indigo-600' : 'text-slate-500 hover:text-slate-800'}`}
                  >
                    International Routes
                  </button>
                </div>
                <div className="relative flex-1">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                  <input 
                    type="text" 
                    placeholder="Search by country or city..." 
                    className="w-full pl-12 pr-4 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl outline-none focus:border-sky-500 font-bold transition-all"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {filteredRoutes.map((r, idx) => (
                  <div 
                    key={idx}
                    onClick={() => handleRouteSelect(r)}
                    className="flex justify-between items-center p-6 border-2 border-slate-100 rounded-3xl hover:border-sky-500 cursor-pointer group transition-all hover:bg-slate-50 hover:shadow-xl"
                  >
                    <div className="flex items-center gap-6">
                      <div className="text-center">
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">FROM</p>
                        <p className="text-xl font-black text-slate-800">{r.from}</p>
                      </div>
                      <div className="relative flex items-center justify-center">
                        <div className="w-12 h-0.5 bg-slate-200 group-hover:bg-sky-400 transition-colors"></div>
                        <Plane size={20} className="absolute text-sky-500 group-hover:translate-x-4 transition-transform" />
                      </div>
                      <div className="text-center">
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">TO</p>
                        <p className="text-xl font-black text-slate-800">{r.to}</p>
                      </div>
                    </div>
                    <div className="text-right border-l-2 border-slate-50 pl-6">
                       <p className="text-xs font-black text-slate-300 line-through">Tk {r.price.toLocaleString()}</p>
                       <p className="text-2xl font-black text-sky-600">Tk {Math.floor(r.price * 0.6).toLocaleString()}</p>
                       <span className="text-[9px] bg-red-100 text-red-600 font-black px-2 py-0.5 rounded-full uppercase tracking-tighter">Save 40%</span>
                    </div>
                  </div>
                ))}
                {filteredRoutes.length === 0 && (
                  <div className="col-span-full py-20 text-center opacity-30">
                    <Globe size={80} className="mx-auto mb-4" />
                    <p className="text-xl font-black uppercase tracking-widest">No routes found for "{searchQuery}"</p>
                  </div>
                )}
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="animate-in fade-in duration-500 max-w-2xl mx-auto py-10">
              <div className="flex items-center gap-4 mb-10 p-6 bg-sky-50 rounded-3xl border-2 border-sky-100">
                <div className="bg-white p-4 rounded-2xl shadow-lg">
                  <Plane className="text-sky-600" size={32} />
                </div>
                <div className="flex-1">
                   <p className="text-[10px] font-black text-sky-600 uppercase tracking-widest">Selected Itinerary</p>
                   <div className="flex justify-between items-center">
                      <span className="text-2xl font-black text-slate-800">{ticketData.from} <span className="text-sky-400">&rarr;</span> {ticketData.to}</span>
                      <span className="text-3xl font-black text-sky-700">Tk {ticketData.discountPrice.toLocaleString()}</span>
                   </div>
                </div>
              </div>

              <div className="space-y-8">
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                   <div className="space-y-2">
                     <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Journey Date</label>
                     <input 
                      type="date" 
                      required
                      className="w-full p-5 bg-slate-50 border-2 border-slate-100 rounded-2xl outline-none focus:border-sky-500 font-black text-lg transition-all" 
                      onChange={e => setTicketData({...ticketData, date: e.target.value})}
                     />
                   </div>
                   {category === 'International' && (
                     <div className="space-y-2">
                       <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Passport Number</label>
                       <input 
                        type="text" 
                        required
                        placeholder="E.g. AF1234567"
                        className="w-full p-5 bg-slate-50 border-2 border-slate-100 rounded-2xl outline-none focus:border-sky-500 font-black text-lg transition-all" 
                        value={ticketData.passportNo}
                        onChange={e => setTicketData({...ticketData, passportNo: e.target.value.toUpperCase()})}
                       />
                     </div>
                   )}
                 </div>
                 
                 <div className="flex gap-4">
                   <button onClick={() => setStep(1)} className="flex-1 py-5 bg-slate-100 text-slate-600 font-black rounded-2xl uppercase tracking-widest text-xs">Change Route</button>
                   <button 
                    onClick={() => setStep(3)}
                    disabled={!ticketData.date || (category === 'International' && !ticketData.passportNo)}
                    className="flex-[2] py-5 bg-slate-900 text-white font-black rounded-2xl shadow-2xl hover:bg-black transition-all uppercase tracking-widest text-xs disabled:opacity-50"
                   >
                     Proceed to Secure Payment
                   </button>
                 </div>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="animate-in fade-in duration-500">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
                <div className="space-y-8">
                   <div className="bg-pink-50 p-8 rounded-[2rem] border-2 border-pink-100 shadow-sm relative overflow-hidden group">
                      <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:scale-125 transition-transform">
                        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/ca/Bkash_Logo.svg/512px-Bkash_Logo.svg.png" className="w-20" />
                      </div>
                      <div className="flex justify-between items-center mb-6">
                         <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/ca/Bkash_Logo.svg/512px-Bkash_Logo.svg.png" className="h-10" />
                         <span className="bg-pink-100 text-pink-700 px-4 py-1 rounded-full text-[10px] font-black uppercase">Official Merchant</span>
                      </div>
                      <p className="text-[10px] font-black text-pink-400 uppercase tracking-widest">bKash Merchant Account (Personal)</p>
                      <div className="flex items-center justify-between mt-2">
                        <span className="text-3xl font-black text-slate-800 tracking-tighter">01700-000000</span>
                        <button className="bg-white p-3 rounded-2xl shadow-md text-pink-600 hover:bg-pink-100 transition-colors"><Copy size={20} /></button>
                      </div>
                   </div>

                   <div className="bg-orange-50 p-8 rounded-[2rem] border-2 border-orange-100 shadow-sm">
                      <div className="flex justify-between items-center mb-6">
                         <h4 className="text-3xl font-black text-orange-600 italic">Nagad</h4>
                         <span className="bg-orange-100 text-orange-700 px-4 py-1 rounded-full text-[10px] font-black uppercase">Official Merchant</span>
                      </div>
                      <p className="text-[10px] font-black text-orange-400 uppercase tracking-widest">Nagad Merchant Account (Personal)</p>
                      <div className="flex items-center justify-between mt-2">
                        <span className="text-3xl font-black text-slate-800 tracking-tighter">01800-000000</span>
                        <button className="bg-white p-3 rounded-2xl shadow-md text-orange-600 hover:bg-orange-100 transition-colors"><Copy size={20} /></button>
                      </div>
                   </div>

                   <div className="bg-slate-900 text-white p-8 rounded-[2rem] flex items-start gap-4 shadow-2xl">
                      {/* Fixed: ShieldCheck is now correctly imported */}
                      <ShieldCheck className="text-emerald-400 shrink-0 mt-1" size={24} />
                      <div>
                        <p className="text-xs font-black uppercase tracking-widest mb-2">Secure Ticketing Protocol</p>
                        <p className="text-[10px] font-bold text-slate-400 leading-relaxed uppercase">Your ticket is subsidized by the ICT Division. Ensure the TrxID matches the amount of Tk {ticketData.discountPrice.toLocaleString()}. Incorrect amounts will result in automatic blacklisting.</p>
                      </div>
                   </div>
                </div>

                <form onSubmit={handleSubmit} className="space-y-8 bg-white p-10 rounded-[2rem] border-2 border-slate-100 shadow-2xl">
                   <div className="space-y-2">
                     <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Transaction ID (TrxID)</label>
                     <input 
                      type="text" 
                      required
                      placeholder="E.g. 8L9X0Z..."
                      className="w-full p-5 bg-slate-50 border-2 border-slate-100 rounded-2xl outline-none focus:border-sky-500 font-mono font-black text-xl tracking-widest"
                      value={ticketData.txId}
                      onChange={e => setTicketData({...ticketData, txId: e.target.value})}
                     />
                   </div>
                   <div className="space-y-2">
                     <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Upload Payment Proof</label>
                     <div className="relative group">
                        <div className="w-full h-48 border-2 border-dashed border-slate-200 rounded-3xl bg-slate-50 flex flex-col items-center justify-center group-hover:border-sky-500 transition-all overflow-hidden relative">
                           {ticketData.screenshot ? (
                             <img src={ticketData.screenshot} className="w-full h-full object-cover" />
                           ) : (
                             <>
                               <Upload className="w-10 h-10 text-slate-300 mb-2 group-hover:text-sky-400 transition-colors" />
                               <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest group-hover:text-sky-500">Drop payment screenshot</span>
                             </>
                           )}
                        </div>
                        <input type="file" required className="absolute inset-0 opacity-0 cursor-pointer" onChange={handleFileUpload} />
                     </div>
                   </div>
                   
                   <div className="flex gap-4">
                     <button type="button" onClick={() => setStep(2)} className="flex-1 py-5 bg-slate-100 text-slate-600 font-black rounded-2xl uppercase tracking-widest text-xs">Back</button>
                     <button 
                      type="submit"
                      className="flex-[2] py-5 bg-sky-600 text-white font-black rounded-2xl shadow-xl hover:bg-sky-700 hover:scale-[1.02] transition-all text-lg flex items-center justify-center gap-3 uppercase tracking-widest border-b-4 border-sky-800"
                     >
                       Confirm Ticket <CheckCircle className="w-6 h-6" />
                     </button>
                   </div>
                </form>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};


import React, { useState } from 'react';
import { ApplicationData } from '../types';
import { 
  Users, 
  Search, 
  CheckCircle, 
  XCircle, 
  Eye, 
  TrendingUp, 
  ArrowLeft,
  LayoutDashboard,
  ShieldCheck,
  Smartphone,
  MapPin,
  Trash2,
  Filter,
  CreditCard,
  FileText
} from 'lucide-react';

interface AdminDashboardProps {
  lang: 'en' | 'bn';
  t: any;
  applications: ApplicationData[];
  onApprove: (id: string) => void;
  onDelete: (id: string) => void;
  onBack: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ 
  lang, 
  t, 
  applications, 
  onApprove, 
  onDelete, 
  onBack 
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<string>('All');
  const [selectedApp, setSelectedApp] = useState<ApplicationData | null>(null);

  const pendingCount = applications.filter(a => a.status === 'Pending').length;
  const approvedCount = applications.filter(a => a.status === 'Approved').length;
  const totalFees = applications.reduce((sum, a) => sum + (a.price || 0), 0);

  const filteredApps = applications.filter(a => {
    const matchesSearch = a.fullName.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          a.nid.includes(searchTerm) || 
                          a.referenceNo.includes(searchTerm);
    const matchesType = filterType === 'All' || a.type === filterType;
    return matchesSearch && matchesType;
  });

  const cardTypes = ['All', 'Family', 'Farmer', 'Student', 'Business', 'BMET', 'AirTicket'];

  return (
    <div className="min-h-screen bg-slate-50 p-4 md:p-8 font-sans">
      <div className="max-w-7xl mx-auto">
        
        {/* Admin Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-10">
          <div>
            <button onClick={onBack} className="flex items-center gap-2 text-slate-500 font-black uppercase text-xs mb-2 hover:text-slate-800 transition-colors">
              <ArrowLeft size={16} /> citizen Portal View
            </button>
            <h2 className="text-3xl font-black text-slate-900 uppercase tracking-tight flex items-center gap-4">
              <div className="bg-emerald-600 p-3 rounded-2xl text-white shadow-xl">
                <ShieldCheck size={28} />
              </div>
              Super Admin Management <span className="text-emerald-600 text-sm ml-2 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-100">Official</span>
            </h2>
          </div>
          
          <div className="flex gap-4 w-full md:w-auto">
             <div className="relative flex-1 md:w-80">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                <input 
                  type="text" 
                  placeholder="Search NID, Name or Ref..." 
                  className="w-full pl-12 pr-4 py-3.5 bg-white border border-slate-200 rounded-2xl shadow-sm outline-none focus:ring-2 focus:ring-emerald-500 transition-all font-bold text-sm"
                  value={searchTerm}
                  onChange={e => setSearchTerm(e.target.value)}
                />
             </div>
          </div>
        </div>

        {/* Overview Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200">
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Total Submissions</p>
            <div className="flex justify-between items-end">
               <p className="text-3xl font-black text-slate-900">{applications.length}</p>
               <Users className="text-slate-200" size={32} />
            </div>
          </div>
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200">
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Pending Review</p>
            <div className="flex justify-between items-end">
               <p className="text-3xl font-black text-amber-500">{pendingCount}</p>
               <FileText className="text-slate-200" size={32} />
            </div>
          </div>
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200">
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Approved Cards</p>
            <div className="flex justify-between items-end">
               <p className="text-3xl font-black text-emerald-600">{approvedCount}</p>
               <CheckCircle className="text-slate-200" size={32} />
            </div>
          </div>
          <div className="bg-emerald-900 p-6 rounded-3xl shadow-xl text-white">
            <p className="text-[10px] font-black text-emerald-400 uppercase tracking-widest mb-1">Total Revenue Collected</p>
            <div className="flex justify-between items-end">
               <p className="text-3xl font-black">{totalFees.toLocaleString()} BDT</p>
               <CreditCard className="text-emerald-700" size={32} />
            </div>
          </div>
        </div>

        {/* Filters */}
        <div className="flex gap-2 mb-6 overflow-x-auto pb-2 scrollbar-hide">
          {cardTypes.map(type => (
            <button 
              key={type}
              onClick={() => setFilterType(type)}
              className={`px-6 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap border ${
                filterType === type 
                ? 'bg-emerald-600 text-white border-emerald-600 shadow-lg' 
                : 'bg-white text-slate-500 border-slate-200 hover:border-emerald-300'
              }`}
            >
              {type}
            </button>
          ))}
        </div>

        {/* Applications List */}
        <div className="bg-white rounded-[2rem] shadow-sm border border-slate-200 overflow-hidden">
          <table className="w-full text-left">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Citizen Details</th>
                <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Service Type</th>
                <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">NID Number</th>
                <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Status</th>
                <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredApps.map(app => (
                <tr key={app.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-8 py-5">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-full bg-slate-100 overflow-hidden flex items-center justify-center">
                        {app.selfie ? <img src={app.selfie} className="w-full h-full object-cover" /> : <Users size={20} className="text-slate-300" />}
                      </div>
                      <div>
                        <p className="font-black text-slate-800 text-sm">{app.fullName}</p>
                        <p className="text-[10px] font-bold text-slate-400">{app.phone}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-8 py-5">
                    <span className="text-[10px] font-black uppercase tracking-widest text-slate-500 bg-slate-100 px-3 py-1 rounded-full">{app.type} Card</span>
                  </td>
                  <td className="px-8 py-5 font-mono text-sm text-slate-600">{app.nid}</td>
                  <td className="px-8 py-5">
                    <div className="flex items-center gap-2">
                       <div className={`w-2 h-2 rounded-full ${app.status === 'Approved' ? 'bg-emerald-500' : 'bg-amber-400 animate-pulse'}`}></div>
                       <span className={`text-[10px] font-black uppercase tracking-widest ${app.status === 'Approved' ? 'text-emerald-600' : 'text-amber-600'}`}>
                         {app.status === 'Approved' ? 'Verified & Approved' : 'Awaiting Review'}
                       </span>
                    </div>
                  </td>
                  <td className="px-8 py-5 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button 
                        onClick={() => setSelectedApp(app)}
                        className="p-2.5 bg-slate-900 text-white rounded-xl hover:bg-black transition-all shadow-md"
                        title="Review Documents"
                      >
                        <Eye size={16} />
                      </button>
                      {app.status === 'Pending' && (
                        <button 
                          onClick={() => onApprove(app.id)}
                          className="p-2.5 bg-emerald-600 text-white rounded-xl hover:bg-emerald-700 transition-all shadow-md"
                          title="Instant Approve"
                        >
                          <CheckCircle size={16} />
                        </button>
                      )}
                      <button 
                        onClick={() => onDelete(app.id)}
                        className="p-2.5 bg-red-100 text-red-600 rounded-xl hover:bg-red-200 transition-all"
                        title="Reject / Delete"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {filteredApps.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-8 py-20 text-center opacity-30">
                     <Search size={64} className="mx-auto mb-4" />
                     <p className="text-xl font-black uppercase tracking-widest">No matching applications found</p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Review Modal */}
      {selectedApp && (
        <div className="fixed inset-0 z-[100] bg-slate-900/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-5xl h-[90vh] rounded-[2.5rem] overflow-hidden flex flex-col shadow-2xl animate-in zoom-in-95 duration-300">
             <div className="bg-slate-900 text-white p-6 flex justify-between items-center border-b border-white/10">
                <div className="flex items-center gap-4">
                   <div className="bg-emerald-600 p-3 rounded-2xl">
                     <FileText size={20} />
                   </div>
                   <div>
                     <h3 className="text-xl font-black uppercase tracking-tight">Application Review</h3>
                     <p className="text-[10px] font-black text-emerald-400 tracking-widest uppercase">REF ID: {selectedApp.referenceNo}</p>
                   </div>
                </div>
                <button onClick={() => setSelectedApp(null)} className="p-3 bg-white/10 rounded-full hover:bg-white/20 transition-all">
                   <XCircle size={24} />
                </button>
             </div>

             <div className="flex-grow overflow-y-auto p-10 bg-slate-50">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
                   
                   {/* Personal Info */}
                   <div className="space-y-8">
                      <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-200">
                         <h4 className="text-xs font-black text-emerald-600 uppercase tracking-[0.2em] mb-6 border-b border-slate-100 pb-3">Personal Details</h4>
                         <div className="grid grid-cols-2 gap-6">
                            <div>
                               <p className="text-[9px] font-black text-slate-400 uppercase mb-1">Full Name</p>
                               <p className="text-sm font-black text-slate-800 uppercase">{selectedApp.fullName}</p>
                            </div>
                            <div>
                               <p className="text-[9px] font-black text-slate-400 uppercase mb-1">NID Number</p>
                               <p className="text-sm font-black text-slate-800">{selectedApp.nid}</p>
                            </div>
                            <div>
                               <p className="text-[9px] font-black text-slate-400 uppercase mb-1">Father's Name</p>
                               <p className="text-sm font-black text-slate-800">{selectedApp.fatherName}</p>
                            </div>
                            <div>
                               <p className="text-[9px] font-black text-slate-400 uppercase mb-1">Mother's Name</p>
                               <p className="text-sm font-black text-slate-800">{selectedApp.motherName}</p>
                            </div>
                            <div className="col-span-2">
                               <p className="text-[9px] font-black text-slate-400 uppercase mb-1">Permanent Address</p>
                               <p className="text-sm font-black text-slate-800 uppercase">
                                 {selectedApp.village}, {selectedApp.union}, {selectedApp.upzilla}, {selectedApp.zilla}
                               </p>
                            </div>
                         </div>
                      </div>

                      <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-200">
                         <h4 className="text-xs font-black text-emerald-600 uppercase tracking-[0.2em] mb-6 border-b border-slate-100 pb-3">Payment Evidence</h4>
                         <div className="flex items-center gap-6">
                            <div className="w-32 h-32 bg-slate-100 rounded-2xl overflow-hidden shadow-inner flex items-center justify-center">
                               {selectedApp.screenshot ? <img src={selectedApp.screenshot} className="w-full h-full object-cover" /> : <Smartphone size={32} className="text-slate-300" />}
                            </div>
                            <div>
                               <p className="text-[9px] font-black text-slate-400 uppercase mb-1">Transaction ID</p>
                               <p className="text-lg font-black text-emerald-600 font-mono">{selectedApp.transactionId || 'NOT_FOUND'}</p>
                               <div className="mt-2 bg-emerald-50 text-emerald-700 px-3 py-1 rounded-full text-[9px] font-black inline-block uppercase">Verified Payment Channel</div>
                            </div>
                         </div>
                      </div>
                   </div>

                   {/* Documents */}
                   <div className="space-y-8">
                      <div className="grid grid-cols-2 gap-6">
                         <div className="space-y-2">
                            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest text-center">Identity Selfie</p>
                            <div className="aspect-[3/4] bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xl">
                               {selectedApp.selfie ? <img src={selectedApp.selfie} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center text-slate-200"><Users size={64} /></div>}
                            </div>
                         </div>
                         <div className="space-y-6">
                            <div className="space-y-2">
                               <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest text-center">NID Front</p>
                               <div className="aspect-video bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-md">
                                  {selectedApp.nidFront ? <img src={selectedApp.nidFront} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center text-slate-100"><Smartphone size={32} /></div>}
                               </div>
                            </div>
                            <div className="space-y-2">
                               <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest text-center">NID Back</p>
                               <div className="aspect-video bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-md">
                                  {selectedApp.nidBack ? <img src={selectedApp.nidBack} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center text-slate-100"><Smartphone size={32} /></div>}
                               </div>
                            </div>
                         </div>
                      </div>

                      <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-inner">
                         <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3">Citizen Digital Signature</p>
                         <div className="h-24 bg-slate-50 rounded-2xl flex items-center justify-center overflow-hidden">
                            {selectedApp.signature ? <img src={selectedApp.signature} className="h-16 object-contain grayscale" /> : <p className="text-[10px] text-slate-300 uppercase font-black">No Signature Recorded</p>}
                         </div>
                      </div>
                   </div>

                </div>
             </div>

             <div className="p-8 bg-white border-t border-slate-100 flex justify-between items-center">
                <button onClick={() => onDelete(selectedApp.id)} className="px-8 py-4 bg-red-100 text-red-600 rounded-2xl font-black uppercase text-xs hover:bg-red-200 transition-all flex items-center gap-2">
                   <Trash2 size={18} /> Reject Application
                </button>
                <div className="flex gap-4">
                   <button onClick={() => setSelectedApp(null)} className="px-8 py-4 bg-slate-100 text-slate-600 rounded-2xl font-black uppercase text-xs hover:bg-slate-200 transition-all">Close</button>
                   {selectedApp.status === 'Pending' && (
                     <button 
                      onClick={() => { onApprove(selectedApp.id); setSelectedApp(null); }} 
                      className="px-12 py-4 bg-emerald-600 text-white rounded-2xl font-black uppercase text-xs shadow-xl hover:bg-emerald-700 transition-all hover:scale-105 active:scale-95 flex items-center gap-2"
                     >
                        <CheckCircle size={18} /> Official Approval
                     </button>
                   )}
                </div>
             </div>
          </div>
        </div>
      )}
    </div>
  );
};


import React, { useState } from 'react';
import { User } from '../types';
import { Eye, EyeOff, Lock, Phone, User as UserIcon, ShieldCheck, AlertCircle, ArrowLeft } from 'lucide-react';
import { db } from '../db';

interface AuthProps {
  mode: 'login' | 'register';
  onLogin?: (user: User) => void;
  onRegister?: (user: User) => void;
  onToggle: () => void;
  onBack: () => void;
  lang: 'en' | 'bn';
  t: any;
}

export const Auth: React.FC<AuthProps> = ({ mode, onLogin, onRegister, onToggle, onBack, lang, t }) => {
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState({
    fullName: '',
    phone: '',
    password: '',
    confirmPassword: '',
    rememberMe: false
  });
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (mode === 'login') {
      // Admin bypass
      if (formData.phone.toLowerCase() === 'admin' && formData.password === 'admin') {
        onLogin?.({ fullName: 'Super Administrator', phone: 'admin', role: 'admin' });
        return;
      }

      const existingUser = await db.findUser(formData.phone);
      if (existingUser && existingUser.password === formData.password) {
        onLogin?.({ 
          fullName: existingUser.fullName, 
          phone: existingUser.phone, 
          role: existingUser.role 
        });
      } else {
        setError(lang === 'bn' ? 'ভুল মোবাইল নম্বর বা পাসওয়ার্ড।' : 'Invalid phone number or password.');
      }
    } else {
      if (formData.password !== formData.confirmPassword) {
        setError(lang === 'bn' ? 'পাসওয়ার্ড দুটি মিলছে না।' : 'Passwords do not match!');
        return;
      }
      
      const existingUser = await db.findUser(formData.phone);
      if (existingUser) {
        setError(lang === 'bn' ? 'এই মোবাইল নম্বর দিয়ে ইতিমধ্যে নিবন্ধন করা হয়েছে।' : 'Phone number already registered.');
        return;
      }

      const newUser: User & { password?: string } = {
        fullName: formData.fullName,
        phone: formData.phone,
        role: 'citizen',
        password: formData.password
      };
      
      await db.saveUser(newUser);
      onRegister?.({ 
        fullName: newUser.fullName, 
        phone: newUser.phone, 
        role: newUser.role 
      });
    }
  };

  return (
    <div className="min-h-[80vh] flex flex-col items-center justify-center p-4 bg-slate-50/50">
      <div className="max-w-md w-full animate-in fade-in slide-in-from-bottom-4 duration-700">
        
        <button 
          onClick={onBack}
          className="flex items-center gap-2 text-[#006a4e] font-black text-xs mb-8 hover:translate-x-[-4px] transition-transform uppercase tracking-widest"
        >
          <ArrowLeft size={16} /> {t.back}
        </button>

        <div className="text-center mb-10">
          <img 
            src="https://upload.wikimedia.org/wikipedia/commons/thumb/8/84/Government_Seal_of_Bangladesh.svg/512px-Government_Seal_of_Bangladesh.svg.png" 
            className="w-24 h-24 mx-auto mb-6 drop-shadow-xl" 
            alt="Gov Seal" 
          />
          <h2 className="text-2xl font-black text-slate-800 tracking-tight uppercase">Authorized Citizen Access</h2>
          <p className="text-[10px] font-black text-[#006a4e] mt-2 tracking-[0.3em] uppercase opacity-80">Smart Portal Security Subsystem</p>
        </div>

        <div className="bg-white rounded-3xl shadow-[0_20px_50px_rgba(0,0,0,0.1)] overflow-hidden border border-slate-200">
          <div className="bg-gradient-to-r from-[#006a4e] to-[#005a42] p-6 text-white flex items-center justify-between">
             <span className="font-black tracking-widest text-sm uppercase">{mode === 'login' ? t.login : t.register}</span>
             <ShieldCheck size={24} className="text-white/80" />
          </div>

          <form onSubmit={handleSubmit} className="p-10 space-y-6">
            {error && (
              <div className="p-4 bg-red-50 border border-red-100 rounded-xl flex items-center gap-3 text-red-600 text-xs font-black uppercase">
                <AlertCircle size={16} /> {error}
              </div>
            )}

            {mode === 'register' && (
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Full Name (As per NID)</label>
                <div className="relative">
                  <UserIcon className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                  <input
                    type="text"
                    required
                    className="w-full pl-10 pr-4 py-4 border-2 border-slate-100 rounded-2xl focus:ring-4 focus:ring-[#006a4e]/5 focus:border-[#006a4e] outline-none transition-all text-sm font-bold bg-slate-50/50"
                    placeholder="Enter full name"
                    value={formData.fullName}
                    onChange={e => setFormData({ ...formData, fullName: e.target.value })}
                  />
                </div>
              </div>
            )}

            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Mobile Number</label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                <input
                  type="text"
                  required
                  className="w-full pl-10 pr-4 py-4 border-2 border-slate-100 rounded-2xl focus:ring-4 focus:ring-[#006a4e]/5 focus:border-[#006a4e] outline-none transition-all text-sm font-bold bg-slate-50/50"
                  placeholder="01XXXXXXXXX or 'admin'"
                  value={formData.phone}
                  onChange={e => setFormData({ ...formData, phone: e.target.value })}
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Secure Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  className="w-full pl-10 pr-12 py-4 border-2 border-slate-100 rounded-2xl focus:ring-4 focus:ring-[#006a4e]/5 focus:border-[#006a4e] outline-none transition-all text-sm font-bold bg-slate-50/50"
                  placeholder="••••••••"
                  value={formData.password}
                  onChange={e => setFormData({ ...formData, password: e.target.value })}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-300 hover:text-[#006a4e] transition-colors"
                >
                  {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                </button>
              </div>
            </div>

            {mode === 'register' && (
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Confirm Password</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    className="w-full pl-10 pr-4 py-4 border-2 border-slate-100 rounded-2xl focus:ring-4 focus:ring-[#006a4e]/5 focus:border-[#006a4e] outline-none transition-all text-sm font-bold bg-slate-50/50"
                    placeholder="••••••••"
                    value={formData.confirmPassword}
                    onChange={e => setFormData({ ...formData, confirmPassword: e.target.value })}
                  />
                </div>
              </div>
            )}

            <div className="flex items-center justify-between">
              <label className="flex items-center gap-2 cursor-pointer select-none group">
                <div className="relative w-4 h-4">
                    <input 
                      type="checkbox" 
                      className="peer absolute inset-0 opacity-0 cursor-pointer"
                      checked={formData.rememberMe}
                      onChange={e => setFormData({ ...formData, rememberMe: e.target.checked })}
                    />
                    <div className="w-4 h-4 border-2 border-slate-300 rounded peer-checked:bg-[#006a4e] peer-checked:border-[#006a4e] transition-all"></div>
                </div>
                <span className="text-[10px] text-slate-500 font-black uppercase tracking-widest group-hover:text-slate-800 transition-colors">Remember Me</span>
              </label>
              <button type="button" className="text-[10px] font-black text-[#f42a41] hover:underline uppercase tracking-widest">Forgot Pass?</button>
            </div>

            <button
              type="submit"
              className="w-full py-5 bg-gradient-to-r from-[#006a4e] to-[#005a42] text-white font-black rounded-2xl uppercase tracking-[0.2em] shadow-xl hover:shadow-2xl hover:scale-[1.02] active:scale-95 transition-all text-xs border-b-4 border-[#004a37]"
            >
              {mode === 'login' ? 'Authorized Login' : 'Create Account Now'}
            </button>
            
            <div className="flex items-start gap-3 p-4 bg-slate-50 rounded-2xl border border-slate-100 text-[9px] text-slate-500 font-bold leading-relaxed">
               <AlertCircle size={16} className="text-[#f42a41] shrink-0 mt-0.5" />
               <p>Identity Verification Security: All login attempts are logged with biometric timestamps and GPS coordinates. Unauthorized access is a federal offense under the Digital Security Act.</p>
            </div>

            <div className="text-center pt-8 border-t border-slate-100">
              <p className="text-xs text-slate-500 font-bold uppercase tracking-wide">
                {mode === 'login' ? "Access required? " : "Already verified? "}
                <button
                  type="button"
                  onClick={onToggle}
                  className="text-[#f42a41] font-black hover:underline uppercase ml-1"
                >
                  {mode === 'login' ? 'Register Now' : 'Back to Login'}
                </button>
              </p>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

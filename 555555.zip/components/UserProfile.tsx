
import React, { useState, useEffect } from 'react';
import { User, ApplicationData, WalletTransaction } from '../types';
import { db } from '../db';
import { 
  ArrowLeft, 
  ShieldCheck, 
  Phone, 
  CreditCard, 
  Wallet, 
  FileText, 
  History,
  ExternalLink,
  Image as ImageIcon,
  CheckCircle2,
  Clock,
  Plus,
  ArrowDownRight,
  ArrowUpRight,
  Copy,
  Check,
  Upload,
  X,
  AlertCircle,
  User as UserIcon,
  Activity
} from 'lucide-react';

interface UserProfileProps {
  user: User;
  applications: ApplicationData[];
  onBack: () => void;
  lang: 'en' | 'bn';
  t: any;
}

export const UserProfile: React.FC<UserProfileProps> = ({ user, applications, onBack, lang, t }) => {
  const [walletTransactions, setWalletTransactions] = useState<WalletTransaction[]>([]);
  const [showDeposit, setShowDeposit] = useState(false);
  const [showWithdraw, setShowWithdraw] = useState(false);
  const [activeTab, setActiveTab] = useState<'applications' | 'wallet'>('applications');
  const [selectedApp, setSelectedApp] = useState<ApplicationData | null>(null);
  const [copied, setCopied] = useState<string | null>(null);
  
  // Form states
  const [depositAmount, setDepositAmount] = useState('');
  const [depositMethod, setDepositMethod] = useState<'bKash' | 'Nagad'>('bKash');
  const [tnxId, setTnxId] = useState('');
  const [screenshot, setScreenshot] = useState<string | null>(null);
  
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [withdrawMethod, setWithdrawMethod] = useState<'bKash' | 'Nagad' | 'Rocket' | 'Upay'>('bKash');
  const [withdrawPhone, setWithdrawPhone] = useState(user.phone);

  const userApplications = applications.filter(app => app.phone === user.phone);

  useEffect(() => {
    const loadWallet = async () => {
      const txs = await db.getWalletTransactions();
      setWalletTransactions(txs.filter(tx => tx.phone === user.phone));
    };
    loadWallet();
  }, [user.phone]);

  const balance = walletTransactions.reduce((acc, tx) => {
    if (tx.status !== 'Success' && tx.type !== 'Withdrawal') return acc;
    if (tx.type === 'Deposit') return acc + tx.amount;
    if (tx.type === 'Withdrawal') return acc - tx.amount;
    if (tx.type === 'Payment') return acc - tx.amount;
    return acc;
  }, 0);

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(text);
    setTimeout(() => setCopied(null), 2000);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setScreenshot(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const submitDeposit = async () => {
    if (!depositAmount || !tnxId) return;
    const newTx: WalletTransaction = {
      id: Math.random().toString(36).substr(2, 9).toUpperCase(),
      phone: user.phone,
      type: 'Deposit',
      amount: parseFloat(depositAmount),
      method: depositMethod,
      status: 'Pending',
      timestamp: new Date().toISOString(),
      transactionId: tnxId,
      screenshot: screenshot
    };
    await db.addWalletTransaction(newTx);
    setWalletTransactions([newTx, ...walletTransactions]);
    setShowDeposit(false);
    setDepositAmount('');
    setTnxId('');
    setScreenshot(null);
  };

  const submitWithdraw = async () => {
    const amount = parseFloat(withdrawAmount);
    if (!withdrawAmount || amount > balance || !withdrawPhone) return;
    const newTx: WalletTransaction = {
      id: Math.random().toString(36).substr(2, 9).toUpperCase(),
      phone: user.phone,
      type: 'Withdrawal',
      amount: amount,
      method: withdrawMethod,
      status: 'Success', 
      timestamp: new Date().toISOString(),
      targetPhone: withdrawPhone
    };
    await db.addWalletTransaction(newTx);
    setWalletTransactions([newTx, ...walletTransactions]);
    setShowWithdraw(false);
    setWithdrawAmount('');
  };

  const latestNidFront = userApplications.find(app => app.nidFront)?.nidFront;
  const latestNidBack = userApplications.find(app => app.nidBack)?.nidBack;
  const latestNid = userApplications.find(app => app.nid)?.nid || 'N/A';
  const latestSelfie = userApplications.find(app => app.selfie)?.selfie;

  const paymentNumbers = {
    bKash: '01700000000',
    Nagad: '01800000000'
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 md:py-12">
      <div className="flex justify-between items-center mb-8">
        <button 
          onClick={onBack}
          className="flex items-center gap-2 text-slate-600 hover:text-gov-green transition-all font-bold uppercase text-[10px] tracking-[0.2em] bg-white px-4 py-2 rounded-lg border border-slate-200 shadow-sm"
        >
          <ArrowLeft size={14} /> {lang === 'bn' ? 'মূল পাতায় ফিরে যান' : 'Return to Portal'}
        </button>
        <div className="flex items-center gap-2 text-[10px] font-black text-slate-400 uppercase tracking-widest">
          <Clock size={12} /> Last Login: {new Date().toLocaleDateString()}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Sidebar: Profile Card */}
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="h-24 bg-[#006a4e] relative">
              <div className="absolute inset-0 opacity-10 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-white via-transparent to-transparent"></div>
            </div>
            <div className="px-6 pb-8 -mt-12 relative text-center">
              <div className="w-24 h-24 rounded-2xl border-4 border-white bg-slate-100 mx-auto shadow-md overflow-hidden mb-4">
                {latestSelfie ? (
                  <img src={latestSelfie} alt="Profile" className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center bg-slate-200 text-slate-400">
                    <UserIcon size={40} />
                  </div>
                )}
              </div>
              <h2 className="text-xl font-black text-slate-800 tracking-tight uppercase mb-1">{user.fullName}</h2>
              <div className="inline-flex items-center gap-1.5 bg-emerald-50 text-emerald-700 px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest border border-emerald-100 mb-6">
                <ShieldCheck size={12} /> Verified Citizen
              </div>
              
              <div className="space-y-3 text-left">
                <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100 group hover:border-[#006a4e]/30 transition-all">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="p-2 bg-white rounded-lg text-[#006a4e] shadow-sm">
                      <Phone size={14} />
                    </div>
                    <div>
                      <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Mobile Number</p>
                      <p className="text-xs font-black text-slate-700">{user.phone}</p>
                    </div>
                  </div>
                  <div className="h-1 w-full bg-slate-200 rounded-full overflow-hidden">
                    <div className="h-full bg-[#006a4e] w-full"></div>
                  </div>
                </div>

                <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100 group hover:border-[#006a4e]/30 transition-all">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="p-2 bg-white rounded-lg text-[#006a4e] shadow-sm">
                      <CreditCard size={14} />
                    </div>
                    <div>
                      <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest">National ID (NID)</p>
                      <p className="text-xs font-black text-slate-700">{latestNid}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-1">
                    <CheckCircle2 size={10} className="text-[#006a4e]" />
                    <span className="text-[8px] font-black text-[#006a4e] uppercase">Identity Verified</span>
                  </div>
                </div>

                <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100 group hover:border-[#006a4e]/30 transition-all">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="p-2 bg-white rounded-lg text-[#006a4e] shadow-sm">
                      <Activity size={14} />
                    </div>
                    <div>
                      <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Profile Status</p>
                      <p className="text-xs font-black text-slate-700">100% Complete</p>
                    </div>
                  </div>
                  <div className="h-1 w-full bg-slate-200 rounded-full overflow-hidden">
                    <div className="h-full bg-[#006a4e] w-full"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-slate-900 rounded-2xl p-6 text-white shadow-2xl relative overflow-hidden group border border-white/5">
            <div className="absolute -right-4 -bottom-4 opacity-10 group-hover:scale-110 transition-transform duration-500">
              <Wallet size={140} className="text-white" />
            </div>
            <div className="absolute top-0 right-0 w-32 h-32 bg-[#006a4e]/20 rounded-full -mr-16 -mt-16 blur-3xl"></div>
            <div className="relative z-10">
              <div className="flex items-center gap-2 mb-2">
                <div className="w-1.5 h-1.5 rounded-full bg-[#006a4e] animate-pulse"></div>
                <p className="text-[9px] font-black uppercase tracking-[0.2em] text-slate-400">Treasury Balance</p>
              </div>
              <h3 className="text-4xl font-black tracking-tighter mb-8 flex items-baseline gap-1">
                <span className="text-2xl font-bold text-[#006a4e]">৳</span>{balance.toLocaleString()}
              </h3>
              <div className="grid grid-cols-1 gap-3">
                <button 
                  onClick={() => setShowDeposit(true)}
                  className="w-full bg-[#006a4e] hover:bg-emerald-700 text-white py-4 rounded-xl font-black uppercase text-[10px] tracking-widest transition-all active:scale-95 shadow-xl shadow-emerald-900/20 flex items-center justify-center gap-2"
                >
                  <Plus size={14} /> Deposit Funds
                </button>
                <button 
                  onClick={() => setShowWithdraw(true)}
                  className="w-full bg-white/5 hover:bg-white/10 text-white py-4 rounded-xl font-black uppercase text-[10px] tracking-widest transition-all active:scale-95 flex items-center justify-center gap-2 border border-white/10"
                >
                  <ArrowUpRight size={14} /> Withdraw
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content Area */}
        <div className="lg:col-span-3 space-y-8">
          {/* Documents Section */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 md:p-8">
            <div className="flex items-center justify-between mb-8 pb-4 border-b border-slate-100">
              <h4 className="text-sm font-black uppercase tracking-widest text-slate-800 flex items-center gap-2">
                <ImageIcon size={18} className="text-gov-green" /> Verified Documents
              </h4>
              <span className="text-[10px] font-bold text-slate-400 uppercase">2 Documents Verified</span>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-3">
                <p className="text-[10px] font-black uppercase tracking-widest text-slate-500 flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-gov-green"></div> NID Front Side
                </p>
                <div className="aspect-[1.6/1] bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-center overflow-hidden shadow-inner group relative">
                  {latestNidFront ? (
                    <>
                      <img src={latestNidFront} alt="NID Front" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <button className="bg-white text-slate-900 px-4 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest shadow-xl">View Full Size</button>
                      </div>
                    </>
                  ) : (
                    <div className="text-center p-4">
                      <ImageIcon size={32} className="mx-auto text-slate-300 mb-2" />
                      <p className="text-[10px] font-bold text-slate-400 uppercase">Not Uploaded</p>
                    </div>
                  )}
                </div>
              </div>
              <div className="space-y-3">
                <p className="text-[10px] font-black uppercase tracking-widest text-slate-500 flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-gov-green"></div> NID Back Side
                </p>
                <div className="aspect-[1.6/1] bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-center overflow-hidden shadow-inner group relative">
                  {latestNidBack ? (
                    <>
                      <img src={latestNidBack} alt="NID Back" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <button className="bg-white text-slate-900 px-4 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest shadow-xl">View Full Size</button>
                      </div>
                    </>
                  ) : (
                    <div className="text-center p-4">
                      <ImageIcon size={32} className="mx-auto text-slate-300 mb-2" />
                      <p className="text-[10px] font-bold text-slate-400 uppercase">Not Uploaded</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Applications & Transactions Tabs */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="flex border-b border-slate-100">
              <button 
                onClick={() => setActiveTab('applications')}
                className={`px-8 py-5 text-[10px] font-black uppercase tracking-widest transition-all ${
                  activeTab === 'applications' ? 'border-b-2 border-gov-green text-gov-green bg-slate-50/50' : 'text-slate-400 hover:text-slate-600'
                }`}
              >
                Application History
              </button>
              <button 
                onClick={() => setActiveTab('wallet')}
                className={`px-8 py-5 text-[10px] font-black uppercase tracking-widest transition-all ${
                  activeTab === 'wallet' ? 'border-b-2 border-gov-green text-gov-green bg-slate-50/50' : 'text-slate-400 hover:text-slate-600'
                }`}
              >
                Financial Logs
              </button>
            </div>
            
            <div className="p-6 md:p-8">
              {activeTab === 'applications' ? (
                <div className="space-y-4">
                  {userApplications.length > 0 ? userApplications.map((app, i) => (
                    <div key={i} className="bg-slate-50/50 border border-slate-100 rounded-2xl p-6 hover:border-gov-green/30 transition-all group">
                      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
                        <div className="flex items-center gap-4">
                          <div className="w-12 h-12 bg-white rounded-xl border border-slate-100 flex items-center justify-center text-gov-green shadow-sm">
                            <CreditCard size={24} />
                          </div>
                          <div>
                            <div className="flex items-center gap-3 mb-1">
                              <h5 className="text-base font-black tracking-tight text-slate-800 uppercase">{app.type} Card Application</h5>
                              <span className={`px-2.5 py-1 rounded-lg text-[8px] font-black uppercase tracking-widest ${
                                app.status === 'Approved' ? 'bg-emerald-100 text-emerald-700 border border-emerald-200' : 'bg-amber-100 text-amber-700 border border-amber-200'
                              }`}>
                                {app.status}
                              </span>
                            </div>
                            <p className="text-[9px] font-bold text-slate-400 uppercase tracking-[0.2em]">Reference No: {app.referenceNo}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-4 w-full md:w-auto">
                          <div className="text-right hidden md:block">
                            <p className="text-[9px] font-black text-slate-400 uppercase mb-1">Fee Paid</p>
                            <p className="text-sm font-black text-slate-800">৳{app.price}</p>
                          </div>
                          <button 
                            onClick={() => setSelectedApp(app)}
                            className="flex-1 md:flex-none bg-white border border-slate-200 px-4 py-2 rounded-xl text-[9px] font-black uppercase tracking-widest hover:bg-slate-50 transition-all flex items-center justify-center gap-2"
                          >
                            <FileText size={14} /> View Details
                          </button>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 md:grid-cols-4 gap-6 pt-6 border-t border-slate-200/50">
                        <div>
                          <p className="text-[8px] font-black uppercase tracking-widest text-slate-400 mb-1.5">Father's Name</p>
                          <p className="text-xs font-bold text-slate-700">{app.fatherName}</p>
                        </div>
                        <div>
                          <p className="text-[8px] font-black uppercase tracking-widest text-slate-400 mb-1.5">Mother's Name</p>
                          <p className="text-xs font-bold text-slate-700">{app.motherName}</p>
                        </div>
                        <div>
                          <p className="text-[8px] font-black uppercase tracking-widest text-slate-400 mb-1.5">Date of Birth</p>
                          <p className="text-xs font-bold text-slate-700">{app.dob}</p>
                        </div>
                        <div>
                          <p className="text-[8px] font-black uppercase tracking-widest text-slate-400 mb-1.5">Location</p>
                          <p className="text-xs font-bold text-slate-700 truncate">{app.zilla}, {app.upzilla}</p>
                        </div>
                      </div>
                    </div>
                  )) : (
                    <div className="text-center py-16 bg-slate-50/50 rounded-2xl border-2 border-dashed border-slate-100">
                      <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mx-auto mb-4 shadow-sm">
                        <FileText size={32} className="text-slate-300" />
                      </div>
                      <p className="text-xs font-black text-slate-400 uppercase tracking-widest">No Active Applications Found</p>
                    </div>
                  )}
                </div>
              ) : (
                <div className="space-y-4">
                  {walletTransactions.length > 0 ? walletTransactions.map((tx, i) => (
                    <div key={i} className="bg-white border border-slate-100 rounded-2xl p-5 flex items-center justify-between hover:border-slate-200 transition-all">
                      <div className="flex items-center gap-4">
                        <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                          tx.type === 'Deposit' ? 'bg-emerald-50 text-[#006a4e]' : 
                          tx.type === 'Withdrawal' ? 'bg-red-50 text-[#f42a41]' : 'bg-blue-50 text-blue-600'
                        }`}>
                          {tx.type === 'Deposit' ? <ArrowDownRight size={20} /> : 
                           tx.type === 'Withdrawal' ? <ArrowUpRight size={20} /> : <CreditCard size={20} />}
                        </div>
                        <div>
                          <p className="text-sm font-black text-slate-800 uppercase tracking-tight">{tx.type} via {tx.method}</p>
                          <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">
                            {new Date(tx.timestamp).toLocaleString()} • ID: {tx.id}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className={`text-sm font-black ${
                          tx.type === 'Deposit' ? 'text-[#006a4e]' : 
                          tx.type === 'Withdrawal' ? 'text-[#f42a41]' : 'text-slate-800'
                        }`}>
                          {tx.type === 'Deposit' ? '+' : '-'}{tx.amount.toLocaleString()} ৳
                        </p>
                        <span className={`text-[8px] font-black uppercase px-2 py-0.5 rounded-full ${
                          tx.status === 'Success' ? 'bg-emerald-100 text-[#006a4e]' : 
                          tx.status === 'Pending' ? 'bg-amber-100 text-amber-700' : 'bg-red-100 text-[#f42a41]'
                        }`}>
                          {tx.status}
                        </span>
                      </div>
                    </div>
                  )) : (
                    <div className="text-center py-16 bg-slate-50/50 rounded-2xl border-2 border-dashed border-slate-100">
                      <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mx-auto mb-4 shadow-sm">
                        <History size={32} className="text-slate-300" />
                      </div>
                      <p className="text-xs font-black text-slate-400 uppercase tracking-widest">No Financial Transactions Found</p>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Application Details Modal */}
      {selectedApp && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-900/80 backdrop-blur-sm" onClick={() => setSelectedApp(null)}></div>
          <div className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl relative z-10 overflow-hidden animate-in zoom-in-95 duration-200 max-h-[90vh] overflow-y-auto">
            <div className="bg-[#006a4e] p-6 text-white flex justify-between items-center sticky top-0 z-10">
              <div>
                <h3 className="text-xl font-black uppercase tracking-tighter">{selectedApp.type} Card Details</h3>
                <p className="text-[10px] font-bold uppercase tracking-widest opacity-80">Reference: {selectedApp.referenceNo}</p>
              </div>
              <button onClick={() => setSelectedApp(null)} className="hover:bg-white/20 p-1 rounded-lg transition-colors">
                <X size={24} />
              </button>
            </div>
            <div className="p-8 space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-4">
                  <h5 className="text-[10px] font-black uppercase tracking-widest text-gov-green border-b border-emerald-100 pb-2">Personal Information</h5>
                  <div className="space-y-3">
                    <div>
                      <p className="text-[8px] font-black uppercase text-slate-400">Full Name</p>
                      <p className="text-sm font-bold text-slate-800">{selectedApp.fullName}</p>
                    </div>
                    <div>
                      <p className="text-[8px] font-black uppercase text-slate-400">Father's Name</p>
                      <p className="text-sm font-bold text-slate-800">{selectedApp.fatherName}</p>
                    </div>
                    <div>
                      <p className="text-[8px] font-black uppercase text-slate-400">Mother's Name</p>
                      <p className="text-sm font-bold text-slate-800">{selectedApp.motherName}</p>
                    </div>
                    <div>
                      <p className="text-[8px] font-black uppercase text-slate-400">Date of Birth</p>
                      <p className="text-sm font-bold text-slate-800">{selectedApp.dob}</p>
                    </div>
                  </div>
                </div>
                <div className="space-y-4">
                  <h5 className="text-[10px] font-black uppercase tracking-widest text-gov-green border-b border-emerald-100 pb-2">Contact & Location</h5>
                  <div className="space-y-3">
                    <div>
                      <p className="text-[8px] font-black uppercase text-slate-400">Mobile Number</p>
                      <p className="text-sm font-bold text-slate-800">{selectedApp.phone}</p>
                    </div>
                    <div>
                      <p className="text-[8px] font-black uppercase text-slate-400">NID Number</p>
                      <p className="text-sm font-bold text-slate-800">{selectedApp.nid}</p>
                    </div>
                    <div>
                      <p className="text-[8px] font-black uppercase text-slate-400">Address</p>
                      <p className="text-sm font-bold text-slate-800">{selectedApp.village}, {selectedApp.union}, {selectedApp.upzilla}, {selectedApp.zilla}</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <h5 className="text-[10px] font-black uppercase tracking-widest text-gov-green border-b border-emerald-100 pb-2">Verification Documents</h5>
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <p className="text-[8px] font-black uppercase text-slate-400 mb-2">Selfie Photo</p>
                    <div className="aspect-square bg-slate-50 rounded-xl border border-slate-200 overflow-hidden">
                      <img src={selectedApp.selfie} className="w-full h-full object-cover" alt="Selfie" />
                    </div>
                  </div>
                  <div>
                    <p className="text-[8px] font-black uppercase text-slate-400 mb-2">NID Front</p>
                    <div className="aspect-square bg-slate-50 rounded-xl border border-slate-200 overflow-hidden">
                      <img src={selectedApp.nidFront} className="w-full h-full object-cover" alt="NID Front" />
                    </div>
                  </div>
                  <div>
                    <p className="text-[8px] font-black uppercase text-slate-400 mb-2">NID Back</p>
                    <div className="aspect-square bg-slate-50 rounded-xl border border-slate-200 overflow-hidden">
                      <img src={selectedApp.nidBack} className="w-full h-full object-cover" alt="NID Back" />
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200 flex justify-between items-center">
                <div>
                  <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-1">Payment Status</p>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 size={16} className="text-emerald-500" />
                    <span className="text-sm font-black text-slate-800 uppercase">৳{selectedApp.price} Paid Successfully</span>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-1">Application Status</p>
                  <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${
                    selectedApp.status === 'Approved' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'
                  }`}>
                    {selectedApp.status}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Deposit Modal */}
      {showDeposit && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-900/80 backdrop-blur-sm" onClick={() => setShowDeposit(false)}></div>
          <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl relative z-10 overflow-hidden animate-in zoom-in-95 duration-200 max-h-[90vh] flex flex-col">
            <div className="bg-gov-green p-6 text-white flex justify-between items-center shrink-0">
              <h3 className="text-xl font-black uppercase tracking-tighter">Deposit Funds</h3>
              <button onClick={() => setShowDeposit(false)} className="hover:bg-white/20 p-1 rounded-lg transition-colors">
                <X size={24} />
              </button>
            </div>
            <div className="p-6 space-y-6 overflow-y-auto custom-scrollbar pb-10">
              <div className="space-y-4">
                <p className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 text-center">Select Payment Method</p>
                <div className="grid grid-cols-2 gap-4">
                  <button 
                    onClick={() => setDepositMethod('bKash')}
                    className={`p-4 rounded-2xl border-2 transition-all flex flex-col items-center gap-3 group relative overflow-hidden ${
                      depositMethod === 'bKash' ? 'border-pink-500 bg-pink-50/50' : 'border-slate-100 hover:border-slate-200 bg-slate-50/30'
                    }`}
                  >
                    {depositMethod === 'bKash' && <div className="absolute top-2 right-2 w-2 h-2 bg-pink-500 rounded-full animate-pulse"></div>}
                    <div className="w-12 h-12 bg-pink-600 rounded-2xl flex items-center justify-center text-white font-black text-sm shadow-lg group-hover:scale-110 transition-transform">bK</div>
                    <span className="text-[10px] font-black uppercase tracking-widest">bKash</span>
                  </button>
                  <button 
                    onClick={() => setDepositMethod('Nagad')}
                    className={`p-4 rounded-2xl border-2 transition-all flex flex-col items-center gap-3 group relative overflow-hidden ${
                      depositMethod === 'Nagad' ? 'border-orange-500 bg-orange-50/50' : 'border-slate-100 hover:border-slate-200 bg-slate-50/30'
                    }`}
                  >
                    {depositMethod === 'Nagad' && <div className="absolute top-2 right-2 w-2 h-2 bg-orange-500 rounded-full animate-pulse"></div>}
                    <div className="w-12 h-12 bg-orange-600 rounded-2xl flex items-center justify-center text-white font-black text-sm shadow-lg group-hover:scale-110 transition-transform">N</div>
                    <span className="text-[10px] font-black uppercase tracking-widest">Nagad</span>
                  </button>
                </div>
              </div>

              <div className="bg-slate-900 rounded-2xl p-5 border border-slate-800 shadow-2xl relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-gov-green/10 rounded-full -mr-16 -mt-16 blur-3xl"></div>
                <div className="relative z-10">
                  <div className="flex items-center gap-2 mb-3">
                    <div className="w-1.5 h-1.5 rounded-full bg-gov-red animate-pulse"></div>
                    <p className="text-[9px] font-black uppercase tracking-[0.2em] text-slate-400">Official Payment Account</p>
                  </div>
                  <div className="flex justify-between items-end">
                    <div>
                      <p className="text-[8px] font-black uppercase text-slate-500 mb-1">Send Money To (Personal)</p>
                      <span className="text-2xl font-black tracking-tighter text-white">{paymentNumbers[depositMethod]}</span>
                    </div>
                    <button 
                      onClick={() => handleCopy(paymentNumbers[depositMethod])}
                      className="bg-white/10 hover:bg-white/20 p-3 rounded-xl transition-all text-white border border-white/5 active:scale-90"
                    >
                      {copied === paymentNumbers[depositMethod] ? <Check size={20} className="text-emerald-400" /> : <Copy size={20} />}
                    </button>
                  </div>
                </div>
              </div>

              <div className="space-y-5">
                <div className="relative">
                  <label className="text-[9px] font-black uppercase tracking-widest text-slate-500 mb-2 block ml-1">Amount to Deposit (BDT)</label>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-black">৳</span>
                    <input 
                      type="number" 
                      value={depositAmount}
                      onChange={(e) => setDepositAmount(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-2xl pl-10 pr-4 py-4 font-black text-lg text-slate-800 focus:ring-2 focus:ring-gov-green focus:bg-white outline-none transition-all"
                      placeholder="0.00"
                    />
                  </div>
                </div>
                
                <div className="relative">
                  <label className="text-[9px] font-black uppercase tracking-widest text-slate-500 mb-2 block ml-1">Transaction ID (TnxID)</label>
                  <input 
                    type="text" 
                    value={tnxId}
                    onChange={(e) => setTnxId(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-4 py-4 font-black text-slate-800 focus:ring-2 focus:ring-gov-green focus:bg-white outline-none transition-all uppercase placeholder:normal-case"
                    placeholder="Enter 10-digit TnxID"
                  />
                </div>

                <div>
                  <label className="text-[9px] font-black uppercase tracking-widest text-slate-500 mb-2 block ml-1">Payment Screenshot</label>
                  <div className="relative">
                    <input 
                      type="file" 
                      onChange={handleFileChange}
                      className="hidden" 
                      id="deposit-screenshot"
                      accept="image/*"
                    />
                    <label 
                      htmlFor="deposit-screenshot"
                      className="w-full bg-slate-50 border-2 border-dashed border-slate-200 rounded-2xl px-4 py-8 flex flex-col items-center gap-3 cursor-pointer hover:bg-slate-100 hover:border-gov-green/30 transition-all group"
                    >
                      {screenshot ? (
                        <div className="relative group/img">
                          <img src={screenshot} alt="Preview" className="h-24 w-auto object-contain rounded-xl shadow-lg" />
                          <div className="absolute inset-0 bg-black/40 rounded-xl opacity-0 group-hover/img:opacity-100 flex items-center justify-center transition-opacity">
                            <Upload size={20} className="text-white" />
                          </div>
                        </div>
                      ) : (
                        <>
                          <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center shadow-sm group-hover:scale-110 transition-transform">
                            <Upload size={24} className="text-gov-green" />
                          </div>
                          <div className="text-center">
                            <span className="text-[10px] font-black uppercase text-slate-500 block">Upload Payment Proof</span>
                            <span className="text-[8px] font-bold text-slate-400 uppercase tracking-widest">JPG, PNG up to 5MB</span>
                          </div>
                        </>
                      )}
                    </label>
                  </div>
                </div>
              </div>

              <div className="pt-2">
                <button 
                  onClick={submitDeposit}
                  className="w-full bg-gov-green hover:bg-emerald-600 text-white py-5 rounded-2xl font-black uppercase text-sm tracking-[0.1em] transition-all active:scale-95 shadow-xl shadow-emerald-900/20 flex items-center justify-center gap-3"
                >
                  <CheckCircle2 size={20} />
                  Confirm & Submit Deposit
                </button>
                <p className="text-[8px] font-bold text-slate-400 text-center mt-4 uppercase tracking-widest">
                  Funds will be added after manual verification (usually 5-30 mins)
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Withdraw Modal */}
      {showWithdraw && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-900/80 backdrop-blur-sm" onClick={() => setShowWithdraw(false)}></div>
          <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl relative z-10 overflow-hidden animate-in zoom-in-95 duration-200 max-h-[90vh] flex flex-col">
            <div className="bg-slate-900 p-6 text-white flex justify-between items-center shrink-0">
              <h3 className="text-xl font-black uppercase tracking-tighter">Withdraw Funds</h3>
              <button onClick={() => setShowWithdraw(false)} className="hover:bg-white/20 p-1 rounded-lg transition-colors">
                <X size={24} />
              </button>
            </div>
            <div className="p-6 space-y-6 overflow-y-auto custom-scrollbar pb-10">
              <div className="bg-slate-900 rounded-2xl p-6 border border-slate-800 shadow-2xl relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-gov-green/10 rounded-full -mr-16 -mt-16 blur-3xl"></div>
                <div className="relative z-10 flex items-center justify-between">
                  <div>
                    <p className="text-[9px] font-black uppercase tracking-[0.2em] text-slate-500 mb-1">Available Balance</p>
                    <p className="text-3xl font-black tracking-tighter text-white">৳{balance.toLocaleString()}</p>
                  </div>
                  <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center text-gov-green border border-white/10">
                    <Wallet size={24} />
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <p className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 text-center">Select Withdrawal Method</p>
                <div className="grid grid-cols-4 gap-2">
                  {['bKash', 'Nagad', 'Rocket', 'Upay'].map((method) => (
                    <button 
                      key={method}
                      onClick={() => setWithdrawMethod(method as any)}
                      className={`p-3 rounded-xl border-2 transition-all flex flex-col items-center gap-2 group ${
                        withdrawMethod === method ? 'border-gov-green bg-emerald-50' : 'border-slate-100 hover:border-slate-200 bg-slate-50/50'
                      }`}
                    >
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-white font-black text-[10px] shadow-sm group-hover:scale-110 transition-transform ${
                        method === 'bKash' ? 'bg-pink-600' : 
                        method === 'Nagad' ? 'bg-orange-600' : 
                        method === 'Rocket' ? 'bg-purple-600' : 'bg-blue-600'
                      }`}>{method.substr(0, 2)}</div>
                      <span className="text-[8px] font-black uppercase tracking-widest">{method}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-5">
                <div className="relative">
                  <label className="text-[9px] font-black uppercase tracking-widest text-slate-500 mb-2 block ml-1">Withdraw Amount (BDT)</label>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-black">৳</span>
                    <input 
                      type="number" 
                      value={withdrawAmount}
                      onChange={(e) => setWithdrawAmount(e.target.value)}
                      className={`w-full bg-slate-50 border rounded-2xl pl-10 pr-4 py-4 font-black text-lg focus:ring-2 focus:ring-gov-green focus:bg-white outline-none transition-all ${
                        parseFloat(withdrawAmount) > balance ? 'border-red-300 text-red-600' : 'border-slate-200 text-slate-800'
                      }`}
                      placeholder="0.00"
                    />
                  </div>
                  {parseFloat(withdrawAmount) > balance && (
                    <p className="text-[9px] font-bold text-red-500 mt-2 flex items-center gap-1 ml-1">
                      <AlertCircle size={12} /> Amount exceeds available balance
                    </p>
                  )}
                </div>

                <div className="relative">
                  <label className="text-[9px] font-black uppercase tracking-widest text-slate-500 mb-2 block ml-1">Receiver Phone Number</label>
                  <input 
                    type="text" 
                    value={withdrawPhone}
                    onChange={(e) => setWithdrawPhone(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-4 py-4 font-black text-slate-800 focus:ring-2 focus:ring-gov-green focus:bg-white outline-none transition-all"
                    placeholder="Enter account number"
                  />
                </div>
              </div>

              <div className="pt-2">
                <button 
                  onClick={submitWithdraw}
                  disabled={!withdrawAmount || parseFloat(withdrawAmount) > balance}
                  className="w-full bg-slate-900 hover:bg-slate-800 disabled:bg-slate-200 disabled:text-slate-400 text-white py-5 rounded-2xl font-black uppercase text-sm tracking-[0.1em] transition-all active:scale-95 shadow-xl flex items-center justify-center gap-3"
                >
                  <ArrowUpRight size={20} />
                  Confirm Withdrawal
                </button>
                <p className="text-[8px] font-bold text-slate-400 text-center mt-4 uppercase tracking-widest">
                  Withdrawals are processed within 24 hours
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

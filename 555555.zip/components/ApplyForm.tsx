
import React, { useState, useRef, useEffect } from 'react';
import { CardType, ApplicationData } from '../types';
import { 
  ArrowLeft, 
  Camera, 
  Upload, 
  Fingerprint, 
  CheckCircle, 
  User as UserIcon,
  Home as HomeIcon,
  CreditCard,
  ChevronRight,
  Pencil,
  Trash2,
  Copy,
  Smartphone,
  ShieldCheck,
  AlertCircle,
  FileText,
  Layers,
  Droplets
} from 'lucide-react';

interface ApplyFormProps {
  type: CardType;
  onComplete: (data: ApplicationData) => void;
  onBack: () => void;
  lang: 'en' | 'bn';
  t: any;
  existingApplications: ApplicationData[];
}

export const ApplyForm: React.FC<ApplyFormProps> = ({ type, onComplete, onBack, lang, t, existingApplications }) => {
  const [step, setStep] = useState(1);
  const [fingerprintProgress, setFingerprintProgress] = useState(0);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [nidError, setNidError] = useState<string | null>(null);

  const cardPrices: Record<string, number> = {
    'Family': 1320,
    'Farmer': 1100,
    'Student': 913,
    'Business': 1912,
    'BMET': 7200,
  };

  const currentPrice = cardPrices[type] || 0;

  const [formData, setFormData] = useState<Partial<ApplicationData>>({
    fullName: '',
    nid: '',
    phone: '',
    fatherName: '',
    motherName: '',
    dob: '',
    zilla: '',
    upzilla: '',
    union: '',
    village: '',
    postOffice: '',
    bloodGroup: '',
    boldGroupSelect: '',
    signature: '',
    transactionId: '',
    screenshot: null,
    selfie: null,
    nidFront: null,
    nidBack: null,
    tinCertificate: null,
  });

  useEffect(() => {
    if (step === 3 && canvasRef.current) {
      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.strokeStyle = '#000';
        ctx.lineWidth = 4;
        ctx.lineCap = 'round';
      }
    }
  }, [step]);

  const startDrawing = (e: React.MouseEvent | React.TouchEvent) => {
    setIsDrawing(true);
    draw(e);
  };

  const stopDrawing = () => {
    setIsDrawing(false);
    if (canvasRef.current) {
      setFormData(prev => ({ ...prev, signature: canvasRef.current?.toDataURL() }));
    }
  };

  const draw = (e: React.MouseEvent | React.TouchEvent) => {
    if (!isDrawing || !canvasRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    let x, y;
    if ('touches' in e) {
      x = e.touches[0].clientX - rect.left;
      y = e.touches[0].clientY - rect.top;
    } else {
      x = e.clientX - rect.left;
      y = e.clientY - rect.top;
    }

    ctx.lineTo(x, y);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(x, y);
  };

  const clearSignature = () => {
    if (canvasRef.current) {
      const ctx = canvasRef.current.getContext('2d');
      ctx?.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height);
      ctx?.beginPath();
      setFormData(prev => ({ ...prev, signature: '' }));
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (name === 'nid') setNidError(null);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, field: string) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData(prev => ({ ...prev, [field]: reader.result }));
      };
      reader.readAsDataURL(file);
    }
  };

  const copyToClipboard = (text: string, field: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(field);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const startFingerprintScan = () => {
    setFingerprintProgress(1);
    const interval = setInterval(() => {
      setFingerprintProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          return 100;
        }
        return prev + 5;
      });
    }, 100);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const isDuplicate = existingApplications.some(app => app.nid === formData.nid);
    if (isDuplicate) {
      setNidError(lang === 'bn' ? "এই এনআইডি নম্বর ইতিমধ্যে নিবন্ধিত আছে। দয়া করে লগইন করার চেষ্টা করুন।" : "This NID is already registered. Please try to login.");
      setStep(1);
      return;
    }

    if (!formData.transactionId || !formData.screenshot) {
      alert(lang === 'bn' ? 'দয়া করে পেমেন্ট সম্পন্ন করুন এবং সঠিক তথ্য দিন।' : 'Please complete payment and provide Transaction ID / Screenshot.');
      return;
    }
    const finalData: ApplicationData = {
      id: Math.random().toString(36).substr(2, 9),
      type: type,
      status: 'Pending',
      referenceNo: 'REF-' + Math.floor(Math.random() * 90000000 + 10000000),
      ...(formData as ApplicationData),
    };
    onComplete(finalData);
  };

  const districts = [
    "Dhaka", "Faridpur", "Gazipur", "Gopalganj", "Kishoreganj", "Madaripur", "Manikganj", "Munshiganj", "Narayanganj", "Narsingdi", "Rajbari", "Shariatpur", "Tangail",
    "Bandarban", "Brahmanbaria", "Chandpur", "Chittagong", "Comilla", "Cox's Bazar", "Feni", "Khagrachhari", "Lakshmipur", "Noakhali", "Rangamati",
    "Barguna", "Barisal", "Bhola", "Jhalokati", "Patuakhali", "Pirojpur",
    "Bagerhat", "Chuadanga", "Jessore", "Jhenaidah", "Khulna", "Kushtia", "Magura", "Meherpur", "Narail", "Satkhira",
    "Jamalpur", "Mymensingh", "Netrokona", "Sherpur",
    "Bogra", "Joypurhat", "Naogaon", "Natore", "Chapainawabganj", "Pabna", "Rajshahi", "Sirajganj",
    "Dinajpur", "Gaibandha", "Kurigram", "Lalmonirhat", "Nilphamari", "Panchagarh", "Rangpur", "Thakurgaon",
    "Habiganj", "Moulvibazar", "Sunamganj", "Sylhet"
  ].sort();

  const bloodGroups = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];
  const boldGroups = ['সাধারণ নাগরিক', 'মুক্তিযোদ্ধা পরিবার', 'সরকারি কর্মচারী', 'প্রতিবন্ধী', 'শিক্ষার্থী', 'প্রবাসী শ্রমিক'];

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <button onClick={onBack} className="flex items-center gap-2 text-gov-green font-black mb-2 hover:translate-x-[-2px] transition-transform uppercase text-xs">
            <ArrowLeft size={16} /> {t.back_dashboard}
          </button>
          <h2 className="text-3xl font-black text-slate-800 uppercase tracking-tight">{type} {t.apply_now}</h2>
        </div>
        
        <div className="flex items-center gap-2">
          {[1, 2, 3, 4].map((s) => (
            <div key={s} className="flex items-center">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center font-black text-xs transition-all ${
                step === s ? 'bg-gov-green text-white scale-110 shadow-lg' : 
                step > s ? 'bg-green-100 text-gov-green' : 'bg-gray-200 text-gray-500'
              }`}>
                {step > s ? <CheckCircle size={20} /> : s}
              </div>
              {s < 4 && <div className={`w-8 h-1 mx-1 rounded ${step > s ? 'bg-gov-green' : 'bg-gray-200'}`}></div>}
            </div>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-3xl shadow-2xl border-4 border-slate-900 overflow-hidden">
        <div className="bg-slate-900 text-white px-8 py-3 flex justify-between items-center">
           <span className="text-[10px] font-black uppercase tracking-[0.4em]">অ্যাডমিনিস্ট্রেটিভ গ্রুপ অ্যাক্সেস - লেভেল ৪</span>
           <span className="text-[10px] font-black uppercase tracking-[0.2em] text-gov-red">সুরক্ষিত সংযোগ</span>
        </div>

        <form onSubmit={handleSubmit}>
          {step === 1 && (
            <div className="p-8 md:p-12 space-y-10 animate-in fade-in duration-500">
              <div className="border-l-8 border-gov-green pl-6">
                 <h3 className="text-2xl font-black text-slate-800 uppercase tracking-tight">{t.personal_profile}</h3>
                 <p className="text-sm font-black text-gov-red uppercase tracking-widest mt-2 animate-pulse">{t.personal_info_sub}</p>
              </div>

              {nidError && (
                <div className="bg-red-50 border-2 border-red-200 p-4 rounded-xl flex items-center gap-3 text-red-600 font-black text-sm uppercase">
                  <AlertCircle /> {nidError}
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">{t.full_name}</label>
                  <input type="text" name="fullName" required className="w-full p-4 border-2 border-slate-100 rounded-xl bg-slate-50 font-black text-slate-700 outline-none focus:border-gov-green" value={formData.fullName} onChange={handleInputChange} />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">{t.nid_number}</label>
                  <input type="text" name="nid" required className={`w-full p-4 border-2 rounded-xl bg-slate-50 font-black text-slate-700 outline-none ${nidError ? 'border-red-500' : 'border-slate-100 focus:border-gov-green'}`} value={formData.nid} onChange={handleInputChange} />
                </div>
                {type === 'BMET' && (
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">পাসপোর্ট নম্বর</label>
                    <input type="text" name="passportNo" required className="w-full p-4 border-2 border-slate-100 rounded-xl bg-slate-50 font-black text-slate-700 outline-none focus:border-gov-green" value={formData.passportNo} onChange={handleInputChange} />
                  </div>
                )}
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">{t.phone_number}</label>
                  <input type="tel" name="phone" required className="w-full p-4 border-2 border-slate-100 rounded-xl bg-slate-50 font-black text-slate-700 outline-none focus:border-gov-green" value={formData.phone} onChange={handleInputChange} />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">{t.dob}</label>
                  <input type="date" name="dob" required className="w-full p-4 border-2 border-slate-100 rounded-xl bg-slate-50 font-black text-slate-700 outline-none focus:border-gov-green" value={formData.dob} onChange={handleInputChange} />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">{t.father_name}</label>
                  <input type="text" name="fatherName" required className="w-full p-4 border-2 border-slate-100 rounded-xl bg-slate-50 font-black text-slate-700 outline-none focus:border-gov-green" value={formData.fatherName} onChange={handleInputChange} />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">{t.mother_name}</label>
                  <input type="text" name="motherName" required className="w-full p-4 border-2 border-slate-100 rounded-xl bg-slate-50 font-black text-slate-700 outline-none focus:border-gov-green" value={formData.motherName} onChange={handleInputChange} />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest flex items-center gap-2">
                    <Droplets size={12} className="text-gov-red" /> {t.blood_group}
                  </label>
                  <select name="bloodGroup" required className="w-full p-4 border-2 border-slate-100 rounded-xl bg-slate-50 font-black text-slate-700 outline-none focus:border-gov-green" value={formData.bloodGroup} onChange={handleInputChange}>
                    <option value="">গ্রুপ নির্বাচন করুন</option>
                    {bloodGroups.map(g => <option key={g} value={g}>{g}</option>)}
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest flex items-center gap-2">
                    <Layers size={12} className="text-gov-green" /> {t.bold_group}
                  </label>
                  <select name="boldGroupSelect" required className="w-full p-4 border-2 border-slate-100 rounded-xl bg-slate-50 font-black text-slate-700 outline-none focus:border-gov-green" value={formData.boldGroupSelect} onChange={handleInputChange}>
                    <option value="">বিভাগ নির্বাচন করুন</option>
                    {boldGroups.map(g => <option key={g} value={g}>{g}</option>)}
                  </select>
                </div>
              </div>
              
              <div className="pt-8 flex justify-end">
                <button type="button" onClick={() => setStep(2)} className="px-12 py-4 bg-slate-900 text-white font-black rounded-2xl shadow-xl hover:scale-105 transition-all flex items-center gap-2 uppercase tracking-widest text-xs">
                  {t.next} <ChevronRight size={18} />
                </button>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="p-8 md:p-12 space-y-10 animate-in fade-in duration-500">
              <div className="border-l-8 border-gov-green pl-6">
                 <h3 className="text-2xl font-black text-slate-800 uppercase tracking-tight flex items-center gap-3">
                   <HomeIcon className="text-gov-green" size={24} /> {t.residency}
                 </h3>
                 <p className="text-xs font-bold text-slate-400 mt-1 uppercase tracking-wider">আপনার বর্তমান ও স্থায়ী ঠিকানার বিস্তারিত প্রদান করুন।</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">{t.zilla}</label>
                  <select name="zilla" required className="w-full p-4 border-2 border-slate-100 rounded-xl bg-slate-50 font-black text-slate-700 outline-none focus:border-gov-green" value={formData.zilla} onChange={handleInputChange}>
                    <option value="">জেলা নির্বাচন করুন</option>
                    {districts.map(d => <option key={d} value={d}>{d}</option>)}
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">{t.upzilla}</label>
                  <input type="text" name="upzilla" required className="w-full p-4 border-2 border-slate-100 rounded-xl bg-slate-50 font-black text-slate-700 outline-none focus:border-gov-green" value={formData.upzilla} onChange={handleInputChange} />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">{t.union}</label>
                  <input type="text" name="union" required className="w-full p-4 border-2 border-slate-100 rounded-xl bg-slate-50 font-black text-slate-700 outline-none focus:border-gov-green" value={formData.union} onChange={handleInputChange} />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">{t.village}</label>
                  <input type="text" name="village" required className="w-full p-4 border-2 border-slate-100 rounded-xl bg-slate-50 font-black text-slate-700 outline-none focus:border-gov-green" value={formData.village} onChange={handleInputChange} />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">{t.post_office}</label>
                  <input type="text" name="postOffice" required className="w-full p-4 border-2 border-slate-100 rounded-xl bg-slate-50 font-black text-slate-700 outline-none focus:border-gov-green" value={formData.postOffice} onChange={handleInputChange} />
                </div>
              </div>

              <div className="pt-8 flex justify-between">
                <button type="button" onClick={() => setStep(1)} className="px-10 py-4 bg-slate-100 text-slate-700 font-black rounded-2xl hover:bg-slate-200 transition-all uppercase tracking-widest text-xs">{t.back}</button>
                <button type="button" onClick={() => setStep(3)} className="px-12 py-4 bg-slate-900 text-white font-black rounded-2xl shadow-xl hover:scale-105 transition-all flex items-center gap-2 uppercase tracking-widest text-xs">
                  {t.next} <ChevronRight size={18} />
                </button>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="p-8 md:p-12 space-y-12 animate-in fade-in duration-500">
              <div className="border-l-8 border-gov-green pl-6">
                 <h3 className="text-2xl font-black text-slate-800 uppercase tracking-tight flex items-center gap-3">
                   <ShieldCheck className="text-gov-green" size={24} /> {t.verification_step}
                 </h3>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
                <div className="lg:col-span-1">
                   <div className="p-8 bg-slate-50 rounded-3xl border-2 border-dashed border-slate-200 text-center">
                      <p className="text-[10px] font-black text-slate-400 uppercase mb-6 tracking-widest">{t.photo_upload}</p>
                      <label className="relative block w-44 h-56 mx-auto cursor-pointer group bg-white border-2 border-slate-100 shadow-2xl rounded-2xl overflow-hidden">
                        {formData.selfie ? (
                          <img src={formData.selfie as string} alt="Selfie" className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full flex flex-col items-center justify-center text-slate-300 group-hover:text-gov-green transition-colors">
                            <Camera size={48} />
                            <span className="text-[10px] font-black mt-3 uppercase tracking-widest">ছবি আপলোড করুন</span>
                          </div>
                        )}
                        <input type="file" className="hidden" accept="image/*" onChange={e => handleFileUpload(e, 'selfie')} />
                      </label>
                   </div>
                </div>

                <div className="lg:col-span-2 space-y-8">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <div className="p-6 bg-white border-2 border-slate-100 rounded-3xl shadow-sm">
                      <p className="text-[10px] font-black text-slate-500 uppercase mb-4 tracking-widest">{t.nid_front}</p>
                      <div className="h-32 bg-slate-50 border-2 border-dashed border-slate-200 rounded-2xl flex flex-col items-center justify-center text-slate-400">
                         {formData.nidFront ? <CheckCircle className="text-gov-green" size={32} /> : <Upload size={32} />}
                         <input type="file" id="nidFront" className="hidden" onChange={e => handleFileUpload(e, 'nidFront')} />
                         <label htmlFor="nidFront" className="mt-4 text-[10px] font-black cursor-pointer hover:text-gov-green underline uppercase tracking-widest">ছবি বেছে নিন</label>
                      </div>
                    </div>
                    <div className="p-6 bg-white border-2 border-slate-100 rounded-3xl shadow-sm">
                      <p className="text-[10px] font-black text-slate-500 uppercase mb-4 tracking-widest">{t.nid_back}</p>
                      <div className="h-32 bg-slate-50 border-2 border-dashed border-slate-200 rounded-2xl flex flex-col items-center justify-center text-slate-400">
                         {formData.nidBack ? <CheckCircle className="text-gov-green" size={32} /> : <Upload size={32} />}
                         <input type="file" id="nidBack" className="hidden" onChange={e => handleFileUpload(e, 'nidBack')} />
                         <label htmlFor="nidBack" className="mt-4 text-[10px] font-black cursor-pointer hover:text-gov-green underline uppercase tracking-widest">ছবি বেছে নিন</label>
                      </div>
                    </div>
                    {type === 'Business' && (
                      <div className="sm:col-span-2 p-6 bg-amber-50 border-2 border-amber-100 rounded-3xl shadow-sm">
                        <p className="text-[10px] font-black text-amber-700 uppercase mb-4 tracking-widest">{t.tin_cert}</p>
                        <div className="h-32 bg-white border-2 border-dashed border-amber-200 rounded-2xl flex flex-col items-center justify-center text-amber-300">
                           {formData.tinCertificate ? <CheckCircle className="text-amber-600" size={32} /> : <FileText size={32} />}
                           <input type="file" id="tinCert" className="hidden" onChange={e => handleFileUpload(e, 'tinCertificate')} />
                           <label htmlFor="tinCert" className="mt-4 text-[10px] font-black cursor-pointer hover:text-amber-600 underline uppercase tracking-widest">নথি আপলোড করুন</label>
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="p-8 bg-slate-50 border-2 border-slate-200 rounded-3xl shadow-xl">
                    <div className="flex justify-between items-center mb-4">
                       <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] flex items-center gap-2">
                         <Pencil size={14} className="text-gov-green" /> {t.signature}
                       </p>
                       <button type="button" onClick={clearSignature} className="text-gov-red hover:bg-red-50 p-2 rounded-xl transition-all flex items-center gap-1">
                         <Trash2 size={16} /> <span className="text-[10px] font-black uppercase">মুছে ফেলুন</span>
                       </button>
                    </div>
                    <div className="relative bg-white border-2 border-slate-300 rounded-2xl h-48 cursor-crosshair overflow-hidden touch-none shadow-inner">
                       <canvas ref={canvasRef} width={600} height={200} className="w-full h-full" onMouseDown={startDrawing} onMouseUp={stopDrawing} onMouseMove={draw} onMouseLeave={stopDrawing} onTouchStart={startDrawing} onTouchEnd={stopDrawing} onTouchMove={draw} />
                       {!formData.signature && (
                         <div className="absolute inset-0 pointer-events-none flex items-center justify-center text-slate-200 font-black uppercase text-[10px] tracking-[1em]">এখানে স্বাক্ষর করুন</div>
                       )}
                    </div>
                  </div>
                </div>
              </div>

              {type === 'BMET' && (
                <div className="p-8 bg-slate-900 rounded-3xl text-white shadow-2xl">
                  <div className="flex flex-col md:flex-row items-center gap-10">
                    <div className="relative">
                      <Fingerprint size={100} className={`${fingerprintProgress > 0 && fingerprintProgress < 100 ? 'text-blue-500 animate-pulse' : fingerprintProgress === 100 ? 'text-gov-green' : 'text-slate-700'}`} />
                      {fingerprintProgress === 100 && <CheckCircle size={32} className="absolute -top-2 -right-2 text-gov-green bg-white rounded-full" />}
                    </div>
                    <div className="flex-1 w-full space-y-6 text-center md:text-left">
                       <h4 className="text-xl font-black uppercase tracking-widest">{t.bmet_biometric}</h4>
                       <div className="h-2 bg-white/5 rounded-full overflow-hidden">
                          <div className="h-full bg-gov-green transition-all duration-300" style={{ width: `${fingerprintProgress}%` }}></div>
                       </div>
                       <button type="button" onClick={startFingerprintScan} className="px-10 py-3 bg-white text-slate-900 font-black text-xs rounded-xl hover:bg-slate-100 transition-all uppercase tracking-widest">
                         {fingerprintProgress === 100 ? 'স্ক্যান সফল' : 'আঙুলের ছাপ স্ক্যান শুরু করুন'}
                       </button>
                    </div>
                  </div>
                </div>
              )}

              <div className="pt-10 flex justify-between">
                <button type="button" onClick={() => setStep(2)} className="px-12 py-4 bg-slate-100 text-slate-700 font-black rounded-2xl hover:bg-slate-200 transition-all uppercase tracking-widest text-xs">{t.back}</button>
                <button type="button" onClick={() => setStep(4)} className="px-12 py-4 bg-slate-900 text-white font-black rounded-2xl shadow-xl hover:scale-105 transition-all flex items-center gap-2 uppercase tracking-widest text-xs">
                  {t.next} <ChevronRight size={18} />
                </button>
              </div>
            </div>
          )}

          {step === 4 && (
            <div className="p-8 md:p-12 space-y-12 animate-in fade-in duration-500">
              <div className="border-l-8 border-gov-green pl-6">
                 <h3 className="text-2xl font-black text-slate-800 uppercase tracking-tight flex items-center gap-3">
                   <CreditCard className="text-gov-green" size={24} /> {t.payment_settlement}
                 </h3>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                <div className="space-y-6">
                   <div className="bg-pink-50 border-2 border-pink-100 p-8 rounded-3xl shadow-sm text-center">
                      <div className="flex justify-between items-center mb-6 text-left">
                        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/ca/Bkash_Logo.svg/512px-Bkash_Logo.svg.png" className="h-10" alt="bKash" />
                        <span className="bg-pink-100 text-pink-700 px-3 py-1 rounded-full text-[10px] font-black uppercase">অফিসিয়াল</span>
                      </div>
                      <div className="mb-4">
                        <p className="text-lg font-black text-slate-800">{t.confirm_payment_msg}</p>
                        <p className="text-4xl font-black text-gov-red mt-2 animate-bounce">{currentPrice} {t.taka}</p>
                      </div>
                      <p className="text-[10px] font-black text-pink-400 uppercase tracking-widest">বিকাশ পার্সোনাল নম্বর</p>
                      <div className="flex items-center justify-between mt-2 text-left">
                         <span className="text-2xl font-black text-slate-800 tracking-tighter">01700-000000</span>
                         <button type="button" onClick={() => copyToClipboard('01700000000', 'bkash')} className={`p-3 rounded-2xl transition-all ${copiedField === 'bkash' ? 'bg-gov-green text-white' : 'bg-white text-pink-600 hover:bg-pink-100'}`}>
                           {copiedField === 'bkash' ? <CheckCircle size={20} /> : <Copy size={20} />}
                         </button>
                      </div>
                   </div>

                   <div className="bg-orange-50 border-2 border-orange-100 p-8 rounded-3xl shadow-sm">
                      <div className="flex justify-between items-center mb-6">
                        <span className="text-3xl font-black text-orange-600 italic">Nagad</span>
                        <span className="bg-orange-100 text-orange-700 px-3 py-1 rounded-full text-[10px] font-black uppercase">অফিসিয়াল</span>
                      </div>
                      <p className="text-[10px] font-black text-orange-400 uppercase tracking-widest">নগদ পার্সোনাল নম্বর</p>
                      <div className="flex items-center justify-between mt-2">
                         <span className="text-2xl font-black text-slate-800 tracking-tighter">01800-000000</span>
                         <button type="button" onClick={() => copyToClipboard('01800000000', 'nagad')} className={`p-3 rounded-2xl transition-all ${copiedField === 'nagad' ? 'bg-gov-green text-white' : 'bg-white text-orange-600 hover:bg-orange-100'}`}>
                           {copiedField === 'nagad' ? <CheckCircle size={20} /> : <Copy size={20} />}
                         </button>
                      </div>
                   </div>
                   
                   <div className="flex items-start gap-4 p-6 bg-slate-900 rounded-3xl text-white">
                      <AlertCircle className="text-gov-red shrink-0" size={20} />
                      <div>
                        <p className="text-xs font-black uppercase tracking-widest mb-2">জরুরী নির্দেশাবলী</p>
                        <p className="text-[10px] font-bold text-slate-400 leading-relaxed uppercase">সার্ভিস ফি: {currentPrice} টাকা। সেন্ড মানি করার পর ট্রানজেকশন আইডি এবং স্ক্রিনশট নিচে প্রদান করুন।</p>
                      </div>
                   </div>
                </div>

                <div className="space-y-8 bg-white p-8 rounded-3xl border-2 border-slate-100 shadow-xl">
                   <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">{t.trx_id}</label>
                      <input type="text" name="transactionId" required placeholder="8LXXXXXXXX" className="w-full p-4 border-2 border-slate-100 rounded-2xl bg-slate-50 font-mono font-black text-lg outline-none focus:border-gov-green" value={formData.transactionId} onChange={handleInputChange} />
                   </div>

                   <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">{t.upload_proof}</label>
                      <div className="relative h-48 bg-slate-50 border-2 border-dashed border-slate-200 rounded-3xl overflow-hidden flex items-center justify-center text-slate-300">
                         {formData.screenshot ? (
                           <img src={formData.screenshot as string} className="w-full h-full object-cover" />
                         ) : (
                           <Upload size={40} />
                         )}
                         <input type="file" required className="absolute inset-0 opacity-0 cursor-pointer" onChange={e => handleFileUpload(e, 'screenshot')} />
                      </div>
                   </div>

                   <button type="submit" className="w-full py-5 bg-gov-red text-white font-black rounded-2xl shadow-2xl hover:scale-105 transition-all text-xl uppercase tracking-[0.2em] border-2 border-white/20">
                     {t.final_submit} <ShieldCheck className="inline-block ml-2" size={24} />
                   </button>
                </div>
              </div>

              <div className="pt-10 flex justify-start border-t border-slate-100">
                <button type="button" onClick={() => setStep(3)} className="px-12 py-4 bg-slate-100 text-slate-700 font-black rounded-2xl hover:bg-slate-200 transition-all uppercase tracking-widest text-xs">{t.back}</button>
              </div>
            </div>
          )}
        </form>
      </div>
    </div>
  );
};
